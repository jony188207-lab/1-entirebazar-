'use strict';
// অটোমেটেড টেস্ট (মেমরি ডাটাবেসে)। চালান: npm test
process.env.APP_SECRET = 'test-secret-test-secret-1234';
process.env.ADMIN_PASSWORD = 'adminpass123';
process.env.BOT_TOKEN = '123456:TESTTOKEN';
process.env.WEBAPP_URL = 'https://example.test';
process.env.ADMIN_CHAT_ID = '999';
delete process.env.SUPABASE_URL;
const crypto = require('crypto');
const tgCalls = [];
const realFetch = global.fetch;
global.fetch = async (u, o) => { if (String(u).startsWith('https://api.telegram.org')) { tgCalls.push(JSON.parse(o.body)); return { json: async () => ({ ok: true }) }; } return realFetch(u, o); };
const { server } = require('./server');
let pass = 0, failN = 0;
const ok = (c, m) => { if (c) { pass++; console.log('  ✓', m); } else { failN++; console.log('  ✗ FAIL:', m); } };
const BASE = 'http://127.0.0.1:3999';
async function call(path, method = 'GET', body, tok) { const r = await fetch(BASE + path, { method, headers: { 'Content-Type': 'application/json', ...(tok ? { Authorization: 'Bearer ' + tok } : {}) }, body: body ? JSON.stringify(body) : undefined }); return { s: r.status, j: await r.json().catch(() => ({})) }; }
function initData(user, tamper) {
  const p = new URLSearchParams({ auth_date: String(Math.floor(Date.now() / 1000)), user: JSON.stringify(user), query_id: 'AAA' });
  const check = [...p.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${k}=${v}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(process.env.BOT_TOKEN).digest();
  p.set('hash', crypto.createHmac('sha256', secret).update(check).digest('hex') + (tamper ? '0' : ''));
  return p.toString();
}
const wait = (ms) => new Promise((r) => setTimeout(r, ms));
server.listen(3999, async () => {
  try {
    console.log('— অ্যাডমিন লগইন');
    ok((await call('/api/admin/login', 'POST', { password: 'wrong' })).s === 401, 'ভুল পাসওয়ার্ড বাতিল');
    const A = (await call('/api/admin/login', 'POST', { password: 'adminpass123' })).j.token; ok(!!A, 'সঠিক পাসওয়ার্ডে টোকেন');
    ok((await call('/api/admin/products')).s === 401, 'টোকেন ছাড়া অ্যাডমিন API বন্ধ');

    console.log('— টেলিগ্রাম অথ');
    ok((await call('/api/auth', 'POST', { initData: initData({ id: 777, first_name: 'Rahim', username: 'rahim' }, true) })).s === 401, 'ভুয়া initData বাতিল');
    const a = await call('/api/auth', 'POST', { initData: initData({ id: 777, first_name: 'Rahim', username: 'rahim' }) });
    ok(a.s === 200 && a.j.user.first_name === 'Rahim', 'সঠিক initData-তে অটো সাইনআপ (নাম টেলিগ্রাম থেকে)');
    const U = a.j.token; await wait(100);
    ok(tgCalls.some((c) => c.chat_id === 777 && /স্বাগতম/.test(c.text)), 'বট: মিনি অ্যাপে ঢুকলে মেসেজ');
    const n1 = tgCalls.length; await call('/api/auth', 'POST', { initData: initData({ id: 777, first_name: 'Rahim' }) }); await wait(100);
    ok(tgCalls.length === n1, '৬ ঘণ্টার মধ্যে আবার ঢুকলে স্প্যাম মেসেজ নেই');
    ok((await call('/api/me')).s === 401, 'টোকেন ছাড়া /me বন্ধ');

    console.log('— অ্যাডমিন কনটেন্ট');
    const cats = (await call('/api/admin/categories', 'GET', null, A)).j; ok(cats.length >= 8, 'শুরুর ক্যাটাগরি + সাব-ক্যাটাগরি আছে');
    const nc = (await call('/api/admin/categories', 'POST', { name: 'Gaming', sort: 9, active: true }, A)).j; ok(nc.id, 'নতুন ক্যাটাগরি যোগ');
    const vpn = cats.find((c) => c.name === 'VPN');
    const pd = (await call('/api/admin/products', 'POST', { name: 'VPN 1 Month', category_id: vpn.id, price: 300, discount_price: 200, type: 'digital', featured: true, images: ['/x.png'] }, A)).j;
    const pp = (await call('/api/admin/products', 'POST', { name: 'T-Shirt', category_id: cats.find((c) => c.name === 'Clothing').id, price: 500, type: 'physical', stock: 5 }, A)).j;
    ok(pd.id && pp.id, 'ডিজিটাল ও ফিজিক্যাল পণ্য যোগ');
    await call('/api/admin/stock', 'POST', { product_id: pd.id, lines: 'KEY-AAA\nKEY-BBB' }, A);
    const bn = (await call('/api/admin/banners', 'POST', { title: 'Sale', image_url: '/b.png', link_type: 'product', link_id: pd.id, active: true, end_at: new Date(Date.now() - 86400e3).toISOString() }, A)).j;
    await call('/api/admin/banners', 'POST', { title: 'Live', image_url: '/b2.png', active: true }, A);
    await call('/api/admin/product_banners', 'POST', { title: 'PB', image_url: '/p.png', link_type: 'category', link_id: vpn.id }, A);
    await call('/api/admin/extra_pages', 'POST', { title: 'Premium', icon: '⭐', product_ids: [pd.id], buttons: [{ label: 'Join', url: 'https://t.me/x' }] }, A);
    const pm = (await call('/api/admin/payment_methods', 'POST', { name: 'bKash', number: '01700000000', min_amount: 50, max_amount: 5000, charge_percent: 2 }, A)).j;
    await call('/api/admin/coupons', 'POST', { code: 'save10', percent: 10 }, A);
    const bs = (await call('/api/bootstrap')).j;
    ok(bs.banners.length === 1 && bs.banners[0].title === 'Live', 'মেয়াদোত্তীর্ণ অ্যাড ব্যানার লুকানো');
    ok(bs.product_banners.length === 1 && bs.extra_pages.length === 1 && bs.categories.some((c) => c.name === 'Gaming'), 'নতুন ক্যাটাগরি/ব্যানার/Extra পেজ কাস্টমারে স্বয়ংক্রিয়');
    ok(bs.products.find((p) => p.id === pd.id).final_price === 200 && bs.products.find((p) => p.id === pd.id).available === 2, 'ডিসকাউন্ট দাম ও ডিজিটাল স্টক');
    ok(!JSON.stringify(bs).includes('KEY-AAA'), 'ডিজিটাল কী পাবলিক API-তে ফাঁস হয় না');
    await call(`/api/admin/categories/${nc.id}`, 'DELETE', null, A); ok(!(await call('/api/bootstrap')).j.categories.some((c) => c.name === 'Gaming'), 'ক্যাটাগরি ডিলিট কাজ করে');

    console.log('— ওয়ালেট / Add Money');
    const dep = async (amount, txid) => call('/api/deposit', 'POST', { method_id: pm.id, amount, txid }, U);
    ok((await dep(10, 'TX0001')).s === 400, 'সর্বনিম্ন সীমার নিচে বাতিল');
    ok((await dep(500, 'a b')).s === 400, 'অবৈধ TxID বাতিল');
    const d1 = await dep(1000, 'TXN12345'); ok(d1.s === 200 && d1.j.deposit.charge === 20, 'ডিপোজিট রিকোয়েস্ট (চার্জ ২%)');
    ok((await dep(1000, 'txn12345')).s === 400, 'একই TxID (ছোট হাতের) দ্বিতীয়বার বাতিল');
    ok((await call('/api/me', 'GET', null, U)).j.user.balance === 0, 'যাচাই ছাড়া ব্যালেন্স বাড়েনি');
    const ap = await call(`/api/admin/deposits/${d1.j.deposit.id}/approve`, 'POST', {}, A); ok(ap.j.status === 'approved', 'অ্যাডমিন অ্যাপ্রুভ');
    ok((await call(`/api/admin/deposits/${d1.j.deposit.id}/approve`, 'POST', {}, A)).s === 400, 'দ্বিতীয়বার অ্যাপ্রুভ করে ডাবল টাকা যোগ হয় না');
    let me = (await call('/api/me', 'GET', null, U)).j; ok(me.user.balance === 1000 && me.ledger.length === 1, 'ওয়ালেট ব্যালেন্স ১০০০ ও লেজার এন্ট্রি');
    const d2 = await dep(300, 'TXN99999'); await call(`/api/admin/deposits/${d2.j.deposit.id}/reject`, 'POST', { note: 'পাইনি' }, A);
    ok((await call('/api/me', 'GET', null, U)).j.user.balance === 1000, 'রিজেক্টে ব্যালেন্স অপরিবর্তিত');

    console.log('— চেকআউট ও ডেলিভারি');
    const before = tgCalls.length;
    const ck = await call('/api/checkout', 'POST', { items: [{ product_id: pd.id, qty: 1 }], coupon: 'SAVE10' }, U);
    ok(ck.s === 200 && ck.j.order.total === 180 && ck.j.order.status === 'completed', 'ডিজিটাল অর্ডার (কুপন ১০% সহ, মোট ১৮০) সম্পূর্ণ');
    ok(ck.j.order.delivery[0].content === 'KEY-AAA', 'স্বয়ংক্রিয় কী ডেলিভারি'); await wait(150);
    const sent = tgCalls.slice(before);
    ok(sent.some((c) => c.chat_id === 777 && /অর্ডার গ্রহণ/.test(c.text)), 'বট: অর্ডার করলে মেসেজ');
    ok(sent.some((c) => c.chat_id === 777 && /অর্ডার সফল/.test(c.text) && /KEY-AAA/.test(c.text)), 'বট: অর্ডার সফল হলে মেসেজ (কীসহ)');
    ok(sent.some((c) => c.chat_id === '999'), 'অ্যাডমিনকে নতুন অর্ডারের অ্যালার্ট');
    ok((await call('/api/checkout', 'POST', { items: [{ product_id: pp.id, qty: 1 }] }, U)).s === 400, 'ফিজিক্যালে ঠিকানা/ফোন ছাড়া বাতিল');
    ok((await call('/api/checkout', 'POST', { items: [{ product_id: pd.id, qty: 1 }, { product_id: pd.id, qty: 5 }] }, U)).s === 400, 'স্টকের বেশি বা ব্যালেন্সের বেশি অর্ডার বাতিল');
    me = (await call('/api/me', 'GET', null, U)).j; ok(me.user.balance === 820, 'ব্যালেন্স সঠিক কাটা (৮২০)');
    const ph = await call('/api/checkout', 'POST', { items: [{ product_id: pp.id, qty: 2 }], address: 'House 1, Road 2, Dhaka', phone: '01711111111' }, U);
    ok(ph.s === 200 && ph.j.order.status === 'processing' && ph.j.order.total === 1060 - 0 || ph.s === 400, 'ফিজিক্যাল: ব্যালেন্স কম হলে বাতিল / যথেষ্ট হলে processing');
    await call(`/api/admin/deposits/${(await dep(2000, 'TXN55555')).j.deposit.id}/approve`, 'POST', {}, A);
    const ph2 = await call('/api/checkout', 'POST', { items: [{ product_id: pp.id, qty: 2 }], address: 'House 1, Road 2, Dhaka', phone: '01711111111' }, U);
    ok(ph2.s === 200 && ph2.j.order.status === 'processing' && ph2.j.order.shipping === 60 && ph2.j.order.total === 1060, 'ফিজিক্যাল অর্ডার (শিপিং ৬০ সহ ১০৬০)');
    ok((await call('/api/bootstrap')).j.products.find((p) => p.id === pp.id).stock === 3, 'ফিজিক্যাল স্টক কমেছে');
    const bal = (await call('/api/me', 'GET', null, U)).j.user.balance;
    const cn = await call(`/api/admin/orders/${ph2.j.order.id}/status`, 'POST', { status: 'cancelled' }, A);
    ok(cn.s === 200 && (await call('/api/me', 'GET', null, U)).j.user.balance === bal + 1060, 'অর্ডার বাতিলে পূর্ণ রিফান্ড');
    ok((await call('/api/bootstrap')).j.products.find((p) => p.id === pp.id).stock === 5, 'বাতিলে স্টক ফিরেছে');
    const sh = await call(`/api/admin/orders/${ck.j.order.id}/status`, 'POST', { status: 'cancelled' }, A); ok(sh.s === 400, 'সম্পন্ন ডিজিটাল অর্ডার বাতিল/রিফান্ড করা যায় না');

    console.log('— রিভিউ ও ধারাবাহিকতা');
    ok((await call('/api/review', 'POST', { product_id: pp.id, rating: 5 }, (await call('/api/auth', 'POST', { initData: initData({ id: 888, first_name: 'Karim' }) })).j.token)).s === 400, 'না কিনে রিভিউ দেওয়া যায় না');
    ok((await call('/api/review', 'POST', { product_id: pd.id, rating: 5, text: 'দারুণ' }, U)).s === 200, 'ক্রেতা রিভিউ দিতে পারে');
    ok((await call('/api/bootstrap')).j.reviews.length === 1, 'রিভিউ হোমে দেখা যায়');
    const st = await call('/api/admin/stats', 'GET', null, A); ok(st.j.customers === 2 && st.j.total_sales === 1, 'ড্যাশবোর্ড স্ট্যাটস');
    const html = await realFetch(BASE + '/'); const adm = await realFetch(BASE + '/admin'); ok(html.status === 200 && adm.status === 200, 'মিনি অ্যাপ ও /admin পেজ লোড হয়');
    ok((await realFetch(BASE + '/..%2f..%2fetc/passwd')).status !== 200, 'পাথ ট্রাভার্সাল বন্ধ');
  } catch (e) { failN++; console.error('টেস্ট ক্র্যাশ:', e); }
  console.log(`\nপাস: ${pass}  ফেল: ${failN}`); server.close(); process.exit(failN ? 1 : 0);
});
