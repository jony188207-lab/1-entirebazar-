'use strict';
const $ = (id) => document.getElementById(id);
const h = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
let TOKEN = sessionStorage.getItem('eb_admin') || '';
const CACHE = {};
function toast(m, e) { const t = $('t'); t.textContent = m; t.className = e ? 'err' : ''; t.style.display = 'block'; setTimeout(() => (t.style.display = 'none'), 2800); }
async function api(path, method = 'GET', body) {
  const r = await fetch('/api/admin' + path, { method, headers: { 'Content-Type': 'application/json', ...(TOKEN ? { Authorization: 'Bearer ' + TOKEN } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (r.status === 401 && path !== '/login') { TOKEN = ''; sessionStorage.removeItem('eb_admin'); showLogin(); throw new Error(j.error); }
  if (!r.ok) throw new Error(j.error || 'ত্রুটি');
  return j;
}
const YN = [['true', 'হ্যাঁ'], ['false', 'না']];
const RES = {
  categories: { title: 'Categories', cols: ['name', 'parent_id', 'sort', 'active'], f: [['name', 'নাম', 'text'], ['parent_id', 'প্যারেন্ট ক্যাটাগরি (সাব-ক্যাটাগরির জন্য)', 'sel:categories'], ['description', 'বিবরণ', 'area'], ['icon_url', 'আইকন', 'img'], ['image_url', 'ইমেজ', 'img'], ['cover_url', 'কভার ইমেজ', 'img'], ['sort', 'ক্রম', 'num'], ['active', 'চালু (Active)', 'bool']] },
  products: { title: 'Products', cols: ['images', 'name', 'price', 'discount_price', 'type', 'stock', 'status'], f: [['name', 'নাম', 'text'], ['category_id', 'ক্যাটাগরি', 'sel:categories'], ['description', 'বিবরণ', 'area'], ['price', 'দাম', 'num'], ['discount_price', 'ছাড়ের দাম (ঐচ্ছিক)', 'num'], ['type', 'ধরন', 'opt:digital,physical'], ['stock', 'স্টক (শুধু Physical-এর জন্য; Digital-এর স্টক "Digital Stock" মেনু থেকে)', 'num'], ['images', 'ছবি/GIF (প্রতি লাইনে একটি URL, বা আপলোড করুন)', 'imgs'], ['video_url', 'ভিডিও', 'img'], ['featured', 'Featured', 'bool'], ['trending', 'Trending', 'bool'], ['special_offer', 'Special Offer', 'bool'], ['recommended', 'Recommended', 'bool'], ['popular', 'Popular', 'bool'], ['status', 'স্ট্যাটাস', 'opt:published,draft']] },
  banners: { title: 'Advertisement Banners', cols: ['image_url', 'title', 'link_type', 'sort', 'active'], f: [['title', 'শিরোনাম', 'text'], ['description', 'বিবরণ', 'text'], ['image_url', 'ব্যানার ইমেজ', 'img'], ['link_type', 'লিংক ধরন', 'opt:none,product,category,url'], ['link_id', 'পণ্য/ক্যাটাগরি', 'linkid'], ['link_url', 'বাহ্যিক লিংক (url হলে)', 'text'], ['start_at', 'শুরুর তারিখ', 'dt'], ['end_at', 'শেষের তারিখ', 'dt'], ['sort', 'ক্রম', 'num'], ['active', 'চালু', 'bool']] },
  product_banners: { title: 'Product Banners', cols: ['image_url', 'title', 'link_type', 'sort', 'active'], f: [['title', 'শিরোনাম', 'text'], ['description', 'বিবরণ', 'text'], ['image_url', 'ব্যানার ইমেজ', 'img'], ['link_type', 'লিংক ধরন', 'opt:none,product,category,url'], ['link_id', 'পণ্য/ক্যাটাগরি', 'linkid'], ['link_url', 'বাহ্যিক লিংক', 'text'], ['start_at', 'শুরুর তারিখ', 'dt'], ['end_at', 'শেষের তারিখ', 'dt'], ['sort', 'ক্রম', 'num'], ['active', 'চালু', 'bool']] },
  extra_pages: { title: 'Extra Pages', cols: ['icon', 'title', 'sort', 'active'], f: [['title', 'পেজের নাম', 'text'], ['icon', 'আইকন (ইমোজি, যেমন ⭐)', 'text'], ['image_url', 'পেজ ইমেজ', 'img'], ['banner_url', 'পেজ ব্যানার', 'img'], ['description', 'সংক্ষিপ্ত বিবরণ', 'area'], ['content', 'পেজের কনটেন্ট', 'area'], ['category_id', 'ক্যাটাগরি সেকশন (ঐচ্ছিক)', 'sel:categories'], ['product_ids', 'প্রোডাক্ট সেকশন (একাধিক বাছুন)', 'multi:products'], ['buttons', 'কাস্টম বাটন/বাহ্যিক লিংক (প্রতি লাইনে: লেখা | https://link)', 'btns'], ['sort', 'ক্রম', 'num'], ['active', 'চালু', 'bool']] },
  payment_methods: { title: 'Payment Methods', cols: ['logo_url', 'name', 'number', 'min_amount', 'max_amount', 'charge_percent', 'active'], f: [['name', 'মেথডের নাম (bKash, Nagad...)', 'text'], ['logo_url', 'লোগো', 'img'], ['number', 'পেমেন্ট নম্বর/অ্যাকাউন্ট', 'text'], ['account_type', 'অ্যাকাউন্ট টাইপ (Personal/Agent/Merchant)', 'text'], ['instructions', 'পেমেন্ট নির্দেশনা', 'area'], ['min_amount', 'সর্বনিম্ন', 'num'], ['max_amount', 'সর্বোচ্চ', 'num'], ['charge_percent', 'ডিপোজিট চার্জ (%)', 'num'], ['sort', 'ক্রম', 'num'], ['active', 'চালু', 'bool']] },
  coupons: { title: 'Coupons', cols: ['code', 'percent', 'used', 'max_uses', 'active'], f: [['code', 'কুপন কোড', 'text'], ['percent', 'ছাড় (%)', 'num'], ['max_uses', 'সর্বোচ্চ ব্যবহার', 'num'], ['active', 'চালু', 'bool']] },
  reviews: { title: 'Reviews', cols: ['user_name', 'rating', 'text', 'approved'], f: [['approved', 'দেখানো হবে (Approved)', 'bool']], noAdd: true },
};
const MENU = [['dash', '📊 Dashboard'], ['deposits', '💰 Deposits'], ['orders', '📦 Orders'], ['stock', '🔑 Digital Stock'], ['categories', '🗂 Categories'], ['products', '🛍 Products'], ['banners', '🖼 Ad Banners'], ['product_banners', '🏷 Product Banners'], ['extra_pages', '✨ Extra Pages'], ['payment_methods', '💳 Payment Methods'], ['coupons', '🎟 Coupons'], ['reviews', '⭐ Reviews'], ['users', '👥 Customers'], ['ledger', '📒 Wallet Ledger'], ['broadcast', '📢 Broadcast'], ['settings', '⚙️ Settings']];
let cur = 'dash';

function showLogin() { $('login').style.display = 'block'; $('shell').style.display = 'none'; }
function showShell() { $('login').style.display = 'none'; $('shell').style.display = 'block'; menu(); go(cur); }
function menu() { $('side').innerHTML = '<h2>EntireBazar</h2>' + MENU.map(([k, l]) => `<a data-k="${k}" class="${k === cur ? 'on' : ''}">${l}</a>`).join('') + '<a id="lo" style="color:var(--err)">⎋ লগআউট</a>'; }
$('side').addEventListener('click', (e) => { const a = e.target.closest('a'); if (!a) return; if (a.id === 'lo') { sessionStorage.removeItem('eb_admin'); TOKEN = ''; return showLogin(); } cur = a.dataset.k; menu(); $('side').classList.remove('open'); go(cur); });
$('mt').onclick = () => $('side').classList.toggle('open');
$('lb').onclick = async () => { try { const j = await api('/login', 'POST', { password: $('pw').value }); TOKEN = j.token; sessionStorage.setItem('eb_admin', TOKEN); showShell(); } catch (e) { toast(e.message, 1); } };
$('pw').addEventListener('keydown', (e) => e.key === 'Enter' && $('lb').click());

async function go(k) {
  try {
    const m = $('main'); m.innerHTML = 'লোড হচ্ছে...';
    if (k === 'dash') return dash();
    if (RES[k]) return crud(k);
    if (k === 'deposits') return deposits();
    if (k === 'orders') return orders();
    if (k === 'stock') return stock();
    if (k === 'users' || k === 'ledger') return plain(k);
    if (k === 'broadcast') return broadcast();
    if (k === 'settings') return settings();
  } catch (e) { toast(e.message, 1); }
}
const fmt = (n) => Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 });
async function dash() {
  const s = await api('/stats');
  $('main').innerHTML = `<h2>Dashboard</h2><div class="cards">${[['Total Sales', s.total_sales], ['Total Revenue', fmt(s.total_revenue)], ['Customers', s.customers], ['Products', s.products], ['Orders', s.orders], ['Pending Deposits', s.pending_deposits]].map(([a, b]) => `<div class="c"><small>${a}</small><b>${b}</b></div>`).join('')}</div>
  <h3>Sales (শেষ ১৪ দিন)</h3><div class="c">${s.daily.length ? s.daily.map(([d, v]) => { const mx = Math.max(...s.daily.map((x) => x[1])); return `<div style="display:flex;gap:8px;align-items:center;margin:4px 0"><small style="width:80px">${d}</small><div style="background:var(--blue);height:14px;border-radius:7px;width:${Math.max(3, (v / mx) * 70)}%"></div><small>${fmt(v)}</small></div>`; }).join('') : 'এখনও বিক্রি নেই'}</div>
  <h3>Recent Orders</h3><div class="tw"><table><tr><th>#</th><th>Total</th><th>Status</th></tr>${s.recent.map((o) => `<tr><td>${h(o.number)}</td><td>${fmt(o.total)}</td><td><span class="pill ${o.status}">${o.status}</span></td></tr>`).join('')}</table></div>`;
}

/* ---- জেনেরিক CRUD ---- */
async function opts(src) { if (!CACHE[src] || Date.now() - CACHE[src].t > 5000) CACHE[src] = { t: Date.now(), v: await api('/' + src) }; return CACHE[src].v; }
async function crud(k) {
  const R = RES[k]; const rows = await api('/' + k);
  const cell = (r, c) => {
    const v = r[c];
    if (c === 'images') return (v || [])[0] ? `<img class="th" src="${h(v[0])}">` : '';
    if (c.endsWith('_url') && v) return `<img class="th" src="${h(v)}">`;
    if (typeof v === 'boolean') return v ? '✅' : '—';
    return h(v ?? '');
  };
  $('main').innerHTML = `<div class="bar"><h2 style="margin:0">${R.title}</h2>${R.noAdd ? '' : '<button id="add">＋ নতুন যোগ করুন</button>'}</div><div class="tw"><table><tr>${R.cols.map((c) => `<th>${c}</th>`).join('')}<th></th></tr>${rows.map((r) => `<tr>${R.cols.map((c) => `<td>${cell(r, c)}</td>`).join('')}<td style="white-space:nowrap"><button class="g s" data-e="${r.id}">এডিট</button> <button class="r s" data-d="${r.id}">ডিলিট</button></td></tr>`).join('') || `<tr><td colspan="${R.cols.length + 1}">কিছু নেই</td></tr>`}</table></div>`;
  if ($('add')) $('add').onclick = () => form(k, null);
  $('main').onclick = async (e) => {
    const b = e.target.closest('button'); if (!b) return;
    if (b.dataset.e) form(k, rows.find((r) => String(r.id) === b.dataset.e));
    if (b.dataset.d && confirm('সত্যিই ডিলিট করবেন?')) { try { await api(`/${k}/${b.dataset.d}`, 'DELETE'); delete CACHE[k]; toast('ডিলিট হয়েছে ✓'); crud(k); } catch (er) { toast(er.message, 1); } }
  };
}
const toLocal = (v) => (v ? new Date(new Date(v).getTime() - new Date(v).getTimezoneOffset() * 6e4).toISOString().slice(0, 16) : '');
async function form(k, row) {
  const R = RES[k]; let html = '';
  for (const [key, label, t] of R.f) {
    const v = row ? row[key] : undefined; let inp = '';
    if (t === 'text') inp = `<input name="${key}" value="${h(v ?? '')}">`;
    else if (t === 'num') inp = `<input name="${key}" type="number" step="any" value="${h(v ?? '')}">`;
    else if (t === 'area') inp = `<textarea name="${key}" rows="3">${h(v ?? '')}</textarea>`;
    else if (t === 'dt') inp = `<input name="${key}" type="datetime-local" value="${toLocal(v)}">`;
    else if (t === 'bool') { html += `<div class="f ck"><input type="checkbox" name="${key}" ${(row ? v : true) ? 'checked' : ''}><label>${label}</label></div>`; continue; }
    else if (t.startsWith('opt:')) inp = `<select name="${key}">${t.slice(4).split(',').map((o) => `<option ${v === o ? 'selected' : ''}>${o}</option>`).join('')}</select>`;
    else if (t.startsWith('sel:')) { const list = await opts(t.slice(4)); inp = `<select name="${key}"><option value="">— নেই —</option>${list.filter((x) => !row || x.id !== row.id).map((x) => `<option value="${x.id}" ${String(v) === String(x.id) ? 'selected' : ''}>${h(x.name)}</option>`).join('')}</select>`; }
    else if (t.startsWith('multi:')) { const list = await opts(t.slice(6)); const sel = (v || []).map(String); inp = `<select name="${key}" multiple size="6">${list.map((x) => `<option value="${x.id}" ${sel.includes(String(x.id)) ? 'selected' : ''}>${h(x.name)}</option>`).join('')}</select><div class="hint">Ctrl/Cmd চেপে একাধিক বাছুন</div>`; }
    else if (t === 'linkid') inp = `<select name="${key}" data-v="${h(v ?? '')}"></select>`;
    else if (t === 'img') inp = `<input name="${key}" value="${h(v ?? '')}" placeholder="URL বা নিচে আপলোড করুন"><input type="file" data-up="${key}" accept="image/*,video/mp4">`;
    else if (t === 'imgs') inp = `<textarea name="${key}" rows="3">${h((v || []).join('\n'))}</textarea><input type="file" data-ups="${key}" accept="image/*" multiple>`;
    else if (t === 'btns') inp = `<textarea name="${key}" rows="3" placeholder="Join Channel | https://t.me/yourchannel">${h((v || []).map((b) => `${b.label} | ${b.url}`).join('\n'))}</textarea>`;
    html += `<div class="f"><label>${label}</label>${inp}</div>`;
  }
  $('mc').innerHTML = `<h3>${row ? 'এডিট' : 'নতুন'} — ${R.title}</h3><form id="fm">${html}<div style="display:flex;gap:10px"><button>সেভ করুন</button><button type="button" class="g" id="cx">বাতিল</button></div></form>`;
  $('modal').classList.add('on'); $('cx').onclick = () => $('modal').classList.remove('on');
  const fm = $('fm');
  const fillLink = async () => { const sel = fm.elements.link_id; if (!sel) return; const type = fm.elements.link_type.value; const list = type === 'product' ? await opts('products') : type === 'category' ? await opts('categories') : []; sel.innerHTML = '<option value="">—</option>' + list.map((x) => `<option value="${x.id}" ${String(sel.dataset.v) === String(x.id) ? 'selected' : ''}>${h(x.name)}</option>`).join(''); };
  if (fm.elements.link_type) { fm.elements.link_type.onchange = () => { fm.elements.link_id.dataset.v = ''; fillLink(); }; fillLink(); }
  const up = async (file) => { if (file.size > 6e6) throw new Error('ফাইল ৬MB-এর কম হতে হবে'); const data = await new Promise((ok) => { const r = new FileReader(); r.onload = () => ok(r.result.split(',')[1]); r.readAsDataURL(file); }); return (await api('/upload', 'POST', { data, ext: file.name.split('.').pop() })).url; };
  fm.addEventListener('change', async (e) => {
    const t = e.target;
    try {
      if (t.dataset.up) { toast('আপলোড হচ্ছে...'); fm.elements[t.dataset.up].value = await up(t.files[0]); toast('আপলোড হয়েছে ✓'); }
      if (t.dataset.ups) { toast('আপলোড হচ্ছে...'); const ta = fm.elements[t.dataset.ups]; for (const f of t.files) ta.value = (ta.value ? ta.value + '\n' : '') + (await up(f)); toast('আপলোড হয়েছে ✓'); }
    } catch (er) { toast(er.message, 1); }
  });
  fm.onsubmit = async (e) => {
    e.preventDefault(); const body = {};
    for (const [key, , t] of R.f) {
      const el = fm.elements[key];
      if (t === 'bool') body[key] = el.checked;
      else if (t === 'imgs') body[key] = el.value.split('\n').map((s) => s.trim()).filter(Boolean);
      else if (t === 'btns') body[key] = el.value.split('\n').map((l) => l.split('|').map((s) => s.trim())).filter((a) => a[0] && a[1]).map(([label, url]) => ({ label, url }));
      else if (t.startsWith('multi:')) body[key] = [...el.selectedOptions].map((o) => Number(o.value));
      else body[key] = el.value;
    }
    try { await api(`/${k}${row ? '/' + row.id : ''}`, row ? 'PUT' : 'POST', body); delete CACHE[k]; $('modal').classList.remove('on'); toast('সেভ হয়েছে ✓'); crud(k); } catch (er) { toast(er.message, 1); }
  };
}

/* ---- ডিপোজিট ---- */
async function deposits() {
  const rows = await api('/deposits'); const users = await api('/users'); const U = Object.fromEntries(users.map((u) => [u.id, u]));
  $('main').innerHTML = `<h2>Deposit Management</h2><div class="tw"><table><tr><th>তারিখ</th><th>গ্রাহক</th><th>মেথড</th><th>টাকা</th><th>TxID</th><th>স্ক্রিনশট</th><th>স্ট্যাটাস</th><th></th></tr>${rows.map((d) => `<tr><td>${new Date(d.created_at).toLocaleString()}</td><td>${h((U[d.user_id] || {}).first_name)} <small>@${h((U[d.user_id] || {}).username || '')}</small></td><td>${h(d.method_name)}</td><td><b>${fmt(d.amount)}</b><br><small>চার্জ ${fmt(d.charge)}</small></td><td>${h(d.txid)}</td><td>${d.screenshot_url ? `<a target="_blank" href="${h(d.screenshot_url)}">দেখুন</a>` : '—'}</td><td><span class="pill ${d.status}">${d.status}</span></td><td>${d.status === 'pending' ? `<button class="s" data-a="approve" data-id="${d.id}">Approve</button> <button class="r s" data-a="reject" data-id="${d.id}">Reject</button>` : h(d.admin_note || '')}</td></tr>`).join('') || '<tr><td colspan="8">কোনো ডিপোজিট নেই</td></tr>'}</table></div>
  <p class="hint">টাকা সত্যিই আপনার অ্যাকাউন্টে এসেছে কিনা bKash/Nagad অ্যাপে মিলিয়ে তবেই Approve করুন। একই TxID দ্বিতীয়বার জমা নেওয়া হয় না।</p>`;
  $('main').onclick = async (e) => { const b = e.target.closest('button'); if (!b || !b.dataset.a) return; try { let body; if (b.dataset.a === 'reject') { const note = prompt('বাতিলের কারণ (গ্রাহক দেখবে):'); if (note === null) return; body = { note }; } else if (!confirm('নিশ্চিত? ওয়ালেটে টাকা যোগ হবে।')) return; await api(`/deposits/${b.dataset.id}/${b.dataset.a}`, 'POST', body || {}); toast('সম্পন্ন ✓'); deposits(); } catch (er) { toast(er.message, 1); } };
}
async function orders() {
  const rows = await api('/orders'); const users = await api('/users'); const U = Object.fromEntries(users.map((u) => [u.id, u]));
  $('main').innerHTML = `<h2>Order Management</h2><div class="tw"><table><tr><th>#</th><th>গ্রাহক</th><th>আইটেম</th><th>মোট</th><th>ঠিকানা</th><th>স্ট্যাটাস</th></tr>${rows.map((o) => `<tr><td>${h(o.number)}<br><small>${new Date(o.created_at).toLocaleDateString()}</small></td><td>${h((U[o.user_id] || {}).first_name)}</td><td>${(o.items || []).map((i) => `${h(i.name)} ×${i.qty}`).join('<br>')}</td><td>${fmt(o.total)}</td><td>${h(o.address || '—')}<br>${h(o.phone || '')}</td><td><select data-id="${o.id}" ${o.status === 'cancelled' ? 'disabled' : ''}>${['pending', 'processing', 'shipped', 'completed', 'cancelled'].map((s) => `<option ${o.status === s ? 'selected' : ''}>${s}</option>`).join('')}</select>${o.tracking ? `<br><small>${h(o.tracking)}</small>` : ''}</td></tr>`).join('') || '<tr><td colspan="6">কোনো অর্ডার নেই</td></tr>'}</table></div><p class="hint">"cancelled" করলে টাকা স্বয়ংক্রিয়ভাবে ওয়ালেটে ফেরত যাবে ও স্টক ফিরবে।</p>`;
  $('main').onchange = async (e) => { const s = e.target; if (!s.dataset.id) return; let tracking; if (s.value === 'shipped') tracking = prompt('কুরিয়ার ট্র্যাকিং নম্বর (ঐচ্ছিক):') || undefined; if (s.value === 'cancelled' && !confirm('বাতিল করে রিফান্ড দেবেন?')) return orders(); try { await api(`/orders/${s.dataset.id}/status`, 'POST', { status: s.value, tracking }); toast('আপডেট হয়েছে ✓'); orders(); } catch (er) { toast(er.message, 1); orders(); } };
}
async function stock() {
  const prods = (await api('/products')).filter((p) => p.type === 'digital'); const rows = await api('/stock');
  const cnt = {}; rows.forEach((r) => { cnt[r.product_id] = cnt[r.product_id] || { f: 0, u: 0 }; r.used ? cnt[r.product_id].u++ : cnt[r.product_id].f++; });
  $('main').innerHTML = `<h2>Digital Stock (License Key / Account / Proxy)</h2>${prods.length ? '' : '<p>আগে Digital ধরনের পণ্য যোগ করুন।</p>'}<div class="c"><div class="f"><label>পণ্য</label><select id="sp">${prods.map((p) => `<option value="${p.id}">${h(p.name)}</option>`).join('')}</select></div><div class="f"><label>প্রতি লাইনে একটি কী/কোড/অ্যাকাউন্ট</label><textarea id="sl" rows="6"></textarea></div><button id="sa">স্টকে যোগ করুন</button></div><h3>স্টক সারাংশ</h3><div class="tw"><table><tr><th>পণ্য</th><th>উপলব্ধ</th><th>বিক্রিত</th></tr>${prods.map((p) => `<tr><td>${h(p.name)}</td><td>${(cnt[p.id] || { f: 0 }).f}</td><td>${(cnt[p.id] || { u: 0 }).u}</td></tr>`).join('')}</table></div>`;
  $('sa').onclick = async () => { try { const j = await api('/stock', 'POST', { product_id: $('sp').value, lines: $('sl').value }); toast(j.added + 'টি যোগ হয়েছে ✓'); stock(); } catch (e) { toast(e.message, 1); } };
}
async function plain(k) {
  const rows = await api('/' + k); const cols = rows[0] ? Object.keys(rows[0]).filter((c) => !['photo_url'].includes(c)) : [];
  $('main').innerHTML = `<h2>${k === 'users' ? 'Customers' : 'Wallet Ledger'}</h2><div class="tw"><table><tr>${cols.map((c) => `<th>${c}</th>`).join('')}</tr>${rows.map((r) => `<tr>${cols.map((c) => `<td>${h(typeof r[c] === 'object' ? JSON.stringify(r[c]) : r[c])}</td>`).join('')}</tr>`).join('')}</table></div>`;
}
async function broadcast() {
  $('main').innerHTML = `<h2>Broadcast Notification</h2><div class="c"><div class="f"><label>শিরোনাম</label><input id="bt" value="📢 EntireBazar"></div><div class="f"><label>বার্তা</label><textarea id="bx" rows="4"></textarea></div><button id="bs">সব গ্রাহকের কাছে পাঠান (মিনি অ্যাপ + টেলিগ্রাম বট)</button></div>`;
  $('bs').onclick = async () => { if (!$('bx').value || !confirm('সবাইকে পাঠাবেন?')) return; try { const j = await api('/broadcast', 'POST', { title: $('bt').value, text: $('bx').value }); toast(j.sent + ' জনকে পাঠানো হয়েছে ✓'); } catch (e) { toast(e.message, 1); } };
}
async function settings() {
  const s = await api('/settings');
  const F = [['store_name', 'স্টোরের নাম'], ['currency', 'কারেন্সি চিহ্ন (৳)'], ['shipping_charge', 'শিপিং চার্জ (Physical পণ্যে)'], ['notice', 'Floating Notice (হোম পেজে নিচে দেখাবে; ফাঁকা রাখলে বন্ধ)'], ['support_url', 'Support লিংক (যেমন https://t.me/yoursupport)']];
  $('main').innerHTML = `<h2>Store Settings</h2><div class="c">${F.map(([k, l]) => `<div class="f"><label>${l}</label><input id="s_${k}" value="${h(s[k] ?? '')}"></div>`).join('')}<button id="ss">সেভ করুন</button></div>`;
  $('ss').onclick = async () => { const b = {}; F.forEach(([k]) => (b[k] = $('s_' + k).value)); try { await api('/settings', 'PUT', b); toast('সেভ হয়েছে ✓'); } catch (e) { toast(e.message, 1); } };
}
$('modal').addEventListener('click', (e) => { if (e.target === $('modal')) $('modal').classList.remove('on'); });
if (TOKEN) showShell(); else showLogin();
