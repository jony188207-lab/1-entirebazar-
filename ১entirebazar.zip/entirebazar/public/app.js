'use strict';
const tg = window.Telegram && window.Telegram.WebApp;
if (tg) { tg.ready(); tg.expand(); try { tg.setHeaderColor('#ffffff'); } catch (e) {} }
const $app = document.getElementById('app');
const S = { token: localStorage.getItem('eb_token') || '', user: null, d: null, me: null, tab: 'home', stack: [], cart: JSON.parse(localStorage.getItem('eb_cart') || '[]'), q: '', cat: null, noticeHidden: false };
const h = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const safeUrl = (u) => (/^(https?:\/\/|\/)/i.test(u || '') ? u : '');
const cur = () => (S.d && S.d.settings.currency) || '৳';
const fm = (n) => `${cur()}${Number(n || 0).toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
const byId = (arr, id) => (arr || []).find((x) => String(x.id) === String(id));

function toast(msg, err) { const t = document.getElementById('toast'); t.textContent = msg; t.className = 'show' + (err ? ' err' : ''); clearTimeout(toast.t); toast.t = setTimeout(() => (t.className = ''), 2800); }
async function api(path, method = 'GET', body) {
  const r = await fetch('/api' + path, { method, headers: { 'Content-Type': 'application/json', ...(S.token ? { Authorization: 'Bearer ' + S.token } : {}) }, body: body ? JSON.stringify(body) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { if (r.status === 401 && path !== '/auth') { await login(); return api(path, method, body); } throw new Error(j.error || 'সমস্যা হয়েছে'); }
  return j;
}
async function login() {
  const dev = new URLSearchParams(location.search).get('dev');
  const j = await api('/auth', 'POST', { initData: tg ? tg.initData : '', dev: dev ? { id: Number(dev), first_name: 'Dev' } : undefined });
  S.token = j.token; S.user = j.user; localStorage.setItem('eb_token', j.token);
}
const saveCart = () => { localStorage.setItem('eb_cart', JSON.stringify(S.cart)); };
const cartCount = () => S.cart.reduce((s, i) => s + i.qty, 0);
async function loadMe() { S.me = await api('/me'); S.user = S.me.user; }

/* ---------- নেভিগেশন ---------- */
function go(type, data = {}) { S.stack.push({ type, ...data }); render(); window.scrollTo(0, 0); }
function back() { S.stack.pop(); render(); }
function setTab(t) { S.tab = t; S.stack = []; render(); window.scrollTo(0, 0); }
if (tg) tg.BackButton.onClick(() => back());

/* ---------- ছোট কম্পোনেন্ট ---------- */
const img = (u, alt) => (safeUrl(u) ? `<img src="${h(safeUrl(u))}" alt="${h(alt || '')}" loading="lazy">` : '');
function card(p) {
  const off = p.discount_price && p.final_price < p.price;
  return `<div class="card" data-a="product" data-id="${p.id}"><div class="im">${img((p.images || [])[0], p.name) || h((p.name || '?')[0])}</div>${off ? `<span class="tag">-${Math.round((1 - p.final_price / p.price) * 100)}%</span>` : ''}<span class="tag dg" style="${p.type === 'digital' ? '' : 'display:none'}">Digital</span><div class="in"><div class="nm">${h(p.name)}</div><div class="price">${fm(p.final_price)}${off ? `<s>${fm(p.price)}</s>` : ''}</div></div></div>`;
}
const section = (title, arr, more) => (arr.length ? `<div class="sec"><h2>${h(title)}${more ? `<a data-a="all">সব দেখুন</a>` : ''}</h2><div class="hscroll">${arr.slice(0, 12).map(card).join('')}</div></div>` : '');
function bannerHtml(list, cls = '') {
  if (!list.length) return '';
  return `<div class="sec ${cls}" style="margin-top:14px"><div class="slider ${cls}" data-slider>${list.map((b) => `<div class="banner" data-a="banner" data-t="${h(cls ? 'pb' : 'ad')}" data-id="${b.id}">${img(b.image_url, b.title)}${b.title ? `<div class="cap"><b>${h(b.title)}</b>${h(b.description || '')}</div>` : ''}</div>`).join('')}</div></div>`;
}
const stars = (n) => '★'.repeat(n) + '☆'.repeat(5 - n);
const ICON = {
  home: '<path d="M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1z"/>',
  products: '<path d="M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z"/>',
  orders: '<path d="M6 2h12v20l-3-2-3 2-3-2-3 2zM9 8h6M9 12h6"/>',
  wallet: '<path d="M3 7h16a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2zM3 7l2-3h12M16 14h2"/>',
  extra: '<path d="M12 3l2.6 5.6 6.1.7-4.5 4.2 1.2 6L12 16.5 6.6 19.5l1.2-6L3.3 9.3l6.1-.7z"/>',
  profile: '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
};
const nav = () => `<div class="nav">${[['home', 'Home'], ['products', 'Products'], ['orders', 'Orders'], ['wallet', 'Wallet'], ['extra', 'Extra'], ['profile', 'Profile']].map(([k, l]) => `<button data-a="tab" data-id="${k}" class="${S.tab === k && !S.stack.length ? 'on' : ''}"><svg viewBox="0 0 24 24">${ICON[k]}</svg>${l}</button>`).join('')}</div>`;
const topbar = (title) => `<div class="top"><button class="back" data-a="back">←</button><h1>${h(title)}</h1><button class="iconbtn" data-a="cart">🛒${cartCount() ? `<span class="badge">${cartCount()}</span>` : ''}</button></div>`;

/* ---------- পেজ ---------- */
function pHome() {
  const { products: P, categories: C, banners, product_banners, reviews, settings } = S.d;
  const top = C.filter((c) => !c.parent_id);
  const sortBy = (f) => [...P].sort(f);
  const secs = [
    ['⭐ Featured Products', P.filter((p) => p.featured)],
    ['🔥 Best Selling', sortBy((a, b) => b.sold - a.sold).filter((p) => p.sold > 0)],
    ['🆕 New Arrivals', sortBy((a, b) => b.id - a.id)],
    ['📈 Trending Products', P.filter((p) => p.trending)],
    ['🎁 Special Offers', P.filter((p) => p.special_offer)],
    ['💸 Discount Products', P.filter((p) => p.final_price < p.price)],
    ['❤️ Popular Products', P.filter((p) => p.popular)],
    ['👍 Recommended For You', P.filter((p) => p.recommended)],
  ];
  const custom = S.d.extra_pages.filter((x) => (x.product_ids || []).length).map((x) => section(x.title, (x.product_ids || []).map((id) => byId(P, id)).filter(Boolean)));
  const rv = reviews.length ? `<div class="sec"><h2>💬 Customer Reviews</h2><div class="hscroll">${reviews.map((r) => `<div class="box" style="flex:0 0 240px;margin:0"><div class="stars">${stars(r.rating)}</div><div style="margin:6px 0">${h(r.text || '')}</div><small style="color:var(--mute)">${h(r.user_name)} · Verified Purchase</small></div>`).join('')}</div></div>` : '';
  return `<div class="screen">
  <div class="walletbar"><div><small>Wallet Balance</small><b>${fm(S.user.balance)}</b></div><button class="btn light" data-a="addmoney">＋ Add Money</button></div>
  <div class="top" style="position:static;border:0;background:none"><div class="logo"><i>E</i>${h(settings.store_name || 'EntireBazar')}</div><button class="iconbtn" data-a="cart">🛒${cartCount() ? `<span class="badge">${cartCount()}</span>` : ''}</button></div>
  <div class="search" style="margin-top:0"><input id="hs" placeholder="পণ্য খুঁজুন..." data-a="searchbox" readonly></div>
  ${bannerHtml(banners)}
  <div class="sec"><h2>Categories</h2><div class="cats">${top.map((c) => `<div class="cat" data-a="cat" data-id="${c.id}"><div class="ic">${img(c.icon_url || c.image_url, c.name) || '▦'}</div>${h(c.name)}</div>`).join('')}</div></div>
  ${bannerHtml(product_banners, 'pb')}
  ${secs.map(([t, a]) => section(t, a)).join('')}${custom.join('')}${rv}
  ${P.length ? '' : '<div class="empty">এখনও কোনো পণ্য যোগ করা হয়নি।</div>'}
  <div style="height:70px"></div></div>
  ${settings.notice && !S.noticeHidden ? `<div class="notice"><span>📢 ${h(settings.notice)}</span><button data-a="hidenotice">✕</button></div>` : ''}`;
}
function pProducts() {
  const C = S.d.categories; const top = C.filter((c) => !c.parent_id);
  const subs = S.cat ? C.filter((c) => String(c.parent_id) === String(S.cat)) : [];
  const ids = S.cat ? [String(S.cat), ...subs.map((s) => String(s.id))] : null;
  const sel = S.cat && byId(C, S.cat);
  const parentOfSel = sel && sel.parent_id ? sel.parent_id : null;
  let list = S.d.products;
  if (S.cat) { const ids2 = sel && sel.parent_id ? [String(sel.id)] : ids; list = list.filter((p) => ids2.includes(String(p.category_id))); }
  if (S.q) list = list.filter((p) => (p.name + ' ' + (p.description || '')).toLowerCase().includes(S.q.toLowerCase()));
  const hist = JSON.parse(localStorage.getItem('eb_hist') || '[]');
  const siblings = parentOfSel ? C.filter((c) => String(c.parent_id) === String(parentOfSel)) : subs;
  return `<div class="screen"><div class="top"><h1>Products</h1><button class="iconbtn" data-a="cart">🛒${cartCount() ? `<span class="badge">${cartCount()}</span>` : ''}</button></div>
  <div class="search"><input id="q" placeholder="পণ্য খুঁজুন..." value="${h(S.q)}"></div>
  ${!S.q && hist.length ? `<div class="chips">${hist.map((x) => `<button class="chip" data-a="hist" data-id="${h(x)}">🕘 ${h(x)}</button>`).join('')}</div>` : ''}
  <div class="chips"><button class="chip ${!S.cat ? 'on' : ''}" data-a="cat" data-id="">সব</button>${top.map((c) => `<button class="chip ${String(S.cat) === String(c.id) || String(parentOfSel) === String(c.id) ? 'on' : ''}" data-a="cat" data-id="${c.id}">${h(c.name)}</button>`).join('')}</div>
  ${siblings.length ? `<div class="chips">${siblings.map((c) => `<button class="chip ${String(S.cat) === String(c.id) ? 'on' : ''}" data-a="cat" data-id="${c.id}">${h(c.name)}</button>`).join('')}</div>` : ''}
  ${list.length ? `<div class="grid" id="pgrid">${list.map(card).join('')}</div>` : '<div class="empty" id="pgrid">কোনো পণ্য পাওয়া যায়নি</div>'}</div>`;
}
function pOrders() {
  const o = S.me.orders;
  return `<div class="screen"><div class="top"><h1>My Orders</h1></div>${o.length ? `<div class="list" style="margin-top:12px">${o.map((x) => `<div class="row" data-a="order" data-id="${x.id}"><div class="grow"><b>${h(x.number)}</b><br><small>${new Date(x.created_at).toLocaleDateString()} · ${(x.items || []).length} আইটেম</small></div><div style="text-align:right"><b>${fm(x.total)}</b><br><span class="pill ${h(x.status)}">${h(x.status)}</span></div></div>`).join('')}</div>` : '<div class="empty">আপনার কোনো অর্ডার নেই</div>'}</div>`;
}
function pOrder(id) {
  const o = byId(S.me.orders, id); if (!o) return '';
  return `<div class="screen">${topbar('Order ' + o.number)}
  <div class="box"><span class="pill ${h(o.status)}">${h(o.status)}</span> <small style="color:var(--mute)">${new Date(o.created_at).toLocaleString()}</small>${o.tracking ? `<div class="note">ট্র্যাকিং: ${h(o.tracking)}</div>` : ''}</div>
  <div class="box"><h3>পণ্য</h3>${(o.items || []).map((i) => `<div class="row" style="border:0;padding:6px 0"><div class="grow">${h(i.name)}<br><small>${i.qty} × ${fm(i.price)}</small></div><b>${fm(i.qty * i.price)}</b></div>`).join('')}
  <hr style="border:0;border-top:1px solid var(--line)"><small>সাবটোটাল ${fm(o.subtotal)} · ছাড় ${fm(o.discount)} · শিপিং ${fm(o.shipping)}</small><div class="price" style="font-size:18px">মোট ${fm(o.total)}</div></div>
  ${(o.delivery || []).length ? `<div class="box"><h3>🔑 আপনার ডিজিটাল পণ্য</h3>${o.delivery.map((k) => `<div style="margin-top:8px"><b>${h(k.name)}</b><div class="code">${h(k.content)}</div><button class="btn ghost" style="margin-top:6px;padding:6px 12px" data-a="copy" data-id="${h(k.content)}">কপি</button></div>`).join('')}</div>` : ''}
  ${o.address ? `<div class="box"><h3>ডেলিভারি ঠিকানা</h3>${h(o.address)}<br>${h(o.phone)}</div>` : ''}
  <div class="pad"><button class="btn block" data-a="reorder" data-id="${o.id}">🔁 আবার অর্ডার করুন</button></div></div>`;
}
function pWallet() {
  const u = S.user; const L = S.me.ledger; const D = S.me.deposits;
  return `<div class="screen"><div class="top"><h1>Wallet</h1></div>
  <div class="walletbar"><div><small>Available Balance</small><b>${fm(u.balance)}</b></div><button class="btn light" data-a="addmoney">＋ Add Money</button></div>
  <div class="stat"><div><small>Total Deposit</small><b>${fm(u.total_deposit)}</b></div><div><small>Total Spent</small><b>${fm(u.total_spent)}</b></div></div>
  <div class="sec"><h2>Deposit History</h2><div class="list">${D.length ? D.map((d) => `<div class="row"><div class="grow"><b>${fm(d.amount)}</b> <small>${h(d.method_name)}</small><br><small>TxID: ${h(d.txid)} · ${new Date(d.created_at).toLocaleDateString()}</small>${d.admin_note ? `<br><small>${h(d.admin_note)}</small>` : ''}</div><span class="pill ${h(d.status)}">${h(d.status)}</span></div>`).join('') : '<div class="empty">কোনো ডিপোজিট নেই</div>'}</div></div>
  <div class="sec"><h2>Transaction History</h2><div class="list">${L.length ? L.map((l) => `<div class="row"><div class="grow"><b>${h(l.type)}</b><br><small>${h(l.note || '')} · ${new Date(l.created_at).toLocaleDateString()}</small></div><div style="text-align:right;color:${l.amount < 0 ? 'var(--err)' : 'var(--ok)'}"><b>${l.amount > 0 ? '+' : ''}${fm(l.amount)}</b><br><small style="color:var(--mute)">ব্যালেন্স ${fm(l.balance_after)}</small></div></div>`).join('') : '<div class="empty">কোনো লেনদেন নেই</div>'}</div></div></div>`;
}
function pAddMoney() {
  const M = S.d.payment_methods; const st = S.stack[S.stack.length - 1];
  const m = byId(M, st.method) || null;
  return `<div class="screen">${topbar('Add Money')}
  <div class="walletbar"><div><small>Current Balance</small><b>${fm(S.user.balance)}</b></div></div>
  ${M.length ? `<div class="box"><h3>Payment Method</h3><div class="pm">${M.map((x) => `<button class="${m && m.id === x.id ? 'on' : ''}" data-a="pmsel" data-id="${x.id}">${img(x.logo_url, x.name)}${h(x.name)}</button>`).join('')}</div>
  ${m ? `<div class="note">${h(m.instructions || 'নিচের নম্বরে টাকা পাঠিয়ে Transaction ID দিন।')}</div>
  ${m.number ? `<div class="numrow"><span>${h(m.account_type || '')} ${h(m.number)}</span><button data-a="copy" data-id="${h(m.number)}">Copy</button></div>` : ''}
  <label class="lab">Deposit Amount (${m.min_amount} – ${m.max_amount})</label><input id="dAmt" type="number" inputmode="decimal" placeholder="যেমন 500">
  <div id="dCharge" class="note" style="display:none"></div>
  <label class="lab">Transaction ID</label><input id="dTx" placeholder="পেমেন্টের Transaction ID" autocapitalize="characters">
  <label class="lab">Payment Screenshot (ঐচ্ছিক)</label><input id="dShot" type="file" accept="image/*">
  <button class="btn block" style="margin-top:14px" data-a="submitdep" data-id="${m.id}">Submit Deposit Request</button>
  <p style="color:var(--mute);font-size:12.5px">অ্যাডমিন যাচাই করার পরই ওয়ালেটে টাকা যোগ হবে। একই Transaction ID দ্বিতীয়বার ব্যবহার করা যাবে না।</p>` : ''}
  </div>` : '<div class="empty">কোনো পেমেন্ট মেথড চালু নেই। অ্যাডমিনের সাথে যোগাযোগ করুন।</div>'}</div>`;
}
function pExtra() {
  const E = S.d.extra_pages;
  return `<div class="screen"><div class="top"><h1>Extra</h1></div>${E.length ? `<div class="grid" style="margin-top:12px">${E.map((x) => `<div class="card" data-a="extrapage" data-id="${x.id}"><div class="im" style="aspect-ratio:1.4;font-size:34px">${img(x.image_url, x.title) || h(x.icon || '✨')}</div><div class="in"><div class="nm" style="height:auto">${h(x.title)}</div><small style="color:var(--mute)">${h((x.description || '').slice(0, 60))}</small></div></div>`).join('')}</div>` : '<div class="empty">এখনও কিছু যোগ করা হয়নি</div>'}</div>`;
}
function pExtraPage(id) {
  const x = byId(S.d.extra_pages, id); if (!x) return '';
  const P = S.d.products;
  let prods = (x.product_ids || []).map((i) => byId(P, i)).filter(Boolean);
  if (x.category_id) { const sub = S.d.categories.filter((c) => String(c.parent_id) === String(x.category_id)).map((c) => String(c.id)); prods = prods.concat(P.filter((p) => [String(x.category_id), ...sub].includes(String(p.category_id)) && !prods.includes(p))); }
  return `<div class="screen">${topbar(x.title)}${x.banner_url ? `<div style="padding:12px 14px 0"><div class="banner">${img(x.banner_url, x.title)}</div></div>` : ''}
  ${x.description ? `<div class="box"><b>${h(x.description)}</b></div>` : ''}${x.content ? `<div class="box" style="white-space:pre-wrap;line-height:1.6">${h(x.content)}</div>` : ''}
  ${(x.buttons || []).length ? `<div class="pad" style="display:grid;gap:10px;margin-top:12px">${x.buttons.map((b) => `<button class="btn block" data-a="link" data-id="${h(b.url)}">${h(b.label)}</button>`).join('')}</div>` : ''}
  ${prods.length ? `<div class="sec"><h2>পণ্য</h2><div class="grid">${prods.map(card).join('')}</div></div>` : ''}</div>`;
}
function pProfile() {
  const u = S.user; const N = S.me.notifications; const unread = N.filter((n) => !n.read).length;
  return `<div class="screen"><div class="top"><h1>Profile</h1></div>
  <div class="box center"><div class="avatar">${img(u.photo_url, u.first_name) || h((u.first_name || '?')[0])}</div><h3 style="margin:10px 0 0">${h((u.first_name || '') + ' ' + (u.last_name || ''))}</h3><small style="color:var(--mute)">${u.username ? '@' + h(u.username) : 'Telegram অ্যাকাউন্ট'}</small></div>
  <div class="stat"><div><small>Wallet</small><b>${fm(u.balance)}</b></div><div><small>Orders</small><b>${S.me.orders.length}</b></div></div>
  <div class="box"><h3>ফোন নম্বর</h3><input id="ph" value="${h(u.phone || '')}" placeholder="01XXXXXXXXX" inputmode="tel"><button class="btn block" style="margin-top:10px" data-a="savephone">সেভ করুন</button></div>
  ${S.d.settings.support_url ? `<div class="pad"><button class="btn ghost block" data-a="link" data-id="${h(S.d.settings.support_url)}">💬 Support / Live Chat</button></div>` : ''}
  <div class="sec"><h2>Notifications ${unread ? `<a data-a="readall">সব পঠিত (${unread})</a>` : ''}</h2><div class="list">${N.length ? N.map((n) => `<div class="row" style="${n.read ? 'opacity:.65' : ''}"><div class="grow"><b>${h(n.title)}</b><br><small>${h(n.body)}</small></div></div>`).join('') : '<div class="empty">কোনো নোটিফিকেশন নেই</div>'}</div></div></div>`;
}
function pProduct(id) {
  const p = byId(S.d.products, id); if (!p) return '';
  const off = p.final_price < p.price; const ok = p.available > 0;
  const rel = S.d.products.filter((x) => x.id !== p.id && x.category_id === p.category_id).slice(0, 8);
  const rv = S.d.reviews.filter((r) => String(r.product_id) === String(p.id));
  const bought = S.me && S.me.orders.some((o) => ['completed', 'processing'].includes(o.status) && (o.items || []).some((i) => String(i.product_id) === String(p.id)));
  const media = [...(p.images || []).map((u) => img(u, p.name)), p.video_url ? `<video src="${h(safeUrl(p.video_url))}" controls playsinline></video>` : ''].filter(Boolean);
  return `<div class="screen">${topbar(p.name)}<div class="gal">${media.length ? media.join('') : `<div class="im" style="display:grid;place-items:center;font-size:60px;color:var(--blue)">${h(p.name[0])}</div>`}</div>
  <div class="box"><div style="display:flex;justify-content:space-between;gap:8px"><h2 style="margin:0;font-size:18px">${h(p.name)}</h2><button class="iconbtn" data-a="share" data-id="${p.id}">↗</button></div>
  <div class="price" style="font-size:22px">${fm(p.final_price)}${off ? `<s>${fm(p.price)}</s>` : ''}</div>
  <span class="pill">${p.type === 'digital' ? 'Digital Product' : 'Physical Product'}</span> <span class="pill ${ok ? 'completed' : 'cancelled'}">${ok ? 'স্টকে আছে' : 'স্টক শেষ'}</span>
  <p style="white-space:pre-wrap;line-height:1.6">${h(p.description || '')}</p></div>
  ${rv.length ? `<div class="box"><h3>Reviews</h3>${rv.map((r) => `<div style="margin-bottom:8px"><span class="stars">${stars(r.rating)}</span> <b>${h(r.user_name)}</b><br>${h(r.text || '')}</div>`).join('')}</div>` : ''}
  ${bought ? `<div class="box"><h3>আপনার রিভিউ দিন</h3><div class="rate" id="rate" data-v="5">${[1, 2, 3, 4, 5].map((n) => `<button data-a="rate" data-id="${n}" class="on">★</button>`).join('')}</div><textarea id="rtxt" rows="2" placeholder="আপনার মতামত"></textarea><button class="btn block" style="margin-top:8px" data-a="sendreview" data-id="${p.id}">রিভিউ জমা দিন</button></div>` : ''}
  ${rel.length ? section('Related Products', rel) : ''}<div style="height:70px"></div>
  <div class="sticky"><button class="btn ghost" ${ok ? '' : 'disabled'} data-a="addcart" data-id="${p.id}">🛒 Add to Cart</button><button class="btn" ${ok ? '' : 'disabled'} data-a="buynow" data-id="${p.id}">Buy Now</button></div></div>`;
}
function pCart() {
  const st = S.stack[S.stack.length - 1];
  const lines = S.cart.map((c) => ({ c, p: byId(S.d.products, c.id) })).filter((x) => x.p);
  if (!lines.length) return `<div class="screen">${topbar('Cart')}<div class="empty">কার্ট খালি</div></div>`;
  const phys = lines.some((x) => x.p.type === 'physical');
  const sub = lines.reduce((s, x) => s + x.p.final_price * x.c.qty, 0);
  const pr = st.price;
  return `<div class="screen">${topbar('Cart & Checkout')}<div class="list" style="margin-top:12px">${lines.map(({ c, p }) => `<div class="row"><div style="width:56px;height:56px;border-radius:10px;overflow:hidden;background:var(--light);flex:0 0 56px">${img((p.images || [])[0], p.name)}</div><div class="grow"><b>${h(p.name)}</b><br><span class="price">${fm(p.final_price)}</span></div><div><div class="qty"><button data-a="qminus" data-id="${p.id}">−</button><span>${c.qty}</span><button data-a="qplus" data-id="${p.id}">+</button></div><br><small data-a="rm" data-id="${p.id}" style="color:var(--err)">মুছুন</small></div></div>`).join('')}</div>
  <div class="box"><label class="lab" style="margin-top:0">Coupon Code</label><div style="display:flex;gap:8px"><input id="cp" value="${h(st.coupon || '')}" placeholder="কুপন কোড"><button class="btn ghost" data-a="applycp">Apply</button></div></div>
  ${phys ? `<div class="box"><h3>ডেলিভারি তথ্য</h3><label class="lab" style="margin-top:0">ঠিকানা</label><textarea id="ad" rows="2" placeholder="পূর্ণ ঠিকানা">${h(st.address || '')}</textarea><label class="lab">ফোন নম্বর</label><input id="phn" value="${h(st.phone || S.user.phone || '')}" inputmode="tel"></div>` : ''}
  <div class="box"><h3>Order Summary</h3><div class="row" style="border:0;padding:3px 0"><div class="grow">সাবটোটাল</div>${fm(pr ? pr.subtotal : sub)}</div>${pr && pr.discount ? `<div class="row" style="border:0;padding:3px 0"><div class="grow">কুপন ছাড়</div>-${fm(pr.discount)}</div>` : ''}${phys ? `<div class="row" style="border:0;padding:3px 0"><div class="grow">শিপিং</div>${fm(pr ? pr.shipping : S.d.settings.shipping_charge)}</div>` : ''}
  <div class="price" style="font-size:20px">মোট ${fm(pr ? pr.total : sub + (phys ? Number(S.d.settings.shipping_charge || 0) : 0))}</div><div class="note">পেমেন্ট: Wallet (ব্যালেন্স ${fm(S.user.balance)})</div></div>
  <div class="pad"><button class="btn block" data-a="confirm">✅ Confirm Order</button></div><div style="height:30px"></div></div>`;
}
function pSuccess() {
  const o = S.stack[S.stack.length - 1].order;
  return `<div class="screen"><div class="box center" style="margin-top:40px"><div style="font-size:54px">${o.status === 'completed' ? '✅' : '🎉'}</div><h2>অর্ডার ${o.status === 'completed' ? 'সফল হয়েছে' : 'গ্রহণ করা হয়েছে'}!</h2><p>অর্ডার নম্বর <b>${h(o.number)}</b><br>মোট ${fm(o.total)}</p>
  ${(o.delivery || []).map((k) => `<div class="code">${h(k.name)}: ${h(k.content)}</div>`).join('')}<p style="color:var(--mute);font-size:13px">টেলিগ্রাম বটেও নোটিফিকেশন পাঠানো হয়েছে।</p><button class="btn block" data-a="gotab" data-id="orders">আমার অর্ডার দেখুন</button></div></div>`;
}

/* ---------- রেন্ডার ---------- */
function render() {
  if (!S.d || !S.me) return;
  const st = S.stack[S.stack.length - 1];
  let html;
  if (st) {
    html = { product: () => pProduct(st.id), cart: pCart, addmoney: pAddMoney, order: () => pOrder(st.id), extrapage: () => pExtraPage(st.id), success: pSuccess }[st.type]();
    if (tg) tg.BackButton.show();
  } else {
    html = { home: pHome, products: pProducts, orders: pOrders, wallet: pWallet, extra: pExtra, profile: pProfile }[S.tab]();
    if (tg) tg.BackButton.hide();
  }
  const keep = document.activeElement && document.activeElement.id === 'q';
  $app.innerHTML = html + nav();
  if (keep) { const q = document.getElementById('q'); q.focus(); q.setSelectionRange(q.value.length, q.value.length); }
  autoSlide();
}
let slideT;
function autoSlide() {
  clearInterval(slideT);
  const s = document.querySelector('[data-slider]:not(.pb)'); if (!s || s.children.length < 2) return;
  let i = 0; slideT = setInterval(() => { i = (i + 1) % s.children.length; s.scrollTo({ left: s.children[i].offsetLeft - s.offsetLeft, behavior: 'smooth' }); }, 4000);
}
function openLink(u) { if (!safeUrl(u)) return; if (tg && /^https?:\/\/t\.me\//.test(u)) tg.openTelegramLink(u); else if (tg) tg.openLink(u); else window.open(u, '_blank'); }
function addCart(id, n = 1) { const c = S.cart.find((x) => String(x.id) === String(id)); const p = byId(S.d.products, id); if (c) c.qty = Math.min(c.qty + n, 20, p.available || 20); else S.cart.push({ id: Number(id), qty: n }); saveCart(); }
async function refreshPrice() {
  const st = S.stack[S.stack.length - 1]; if (!st || st.type !== 'cart') return;
  try { st.price = await api('/cart/price', 'POST', { items: S.cart.map((c) => ({ product_id: c.id, qty: c.qty })), coupon: st.coupon || '' }); } catch (e) { st.price = null; if (st.coupon) { toast(e.message, 1); st.coupon = ''; } }
  render();
}

/* ---------- ক্লিক হ্যান্ডলার ---------- */
document.addEventListener('click', async (e) => {
  const el = e.target.closest('[data-a]'); if (!el) return;
  const a = el.dataset.a; const id = el.dataset.id; const st = S.stack[S.stack.length - 1];
  try {
    if (a === 'tab') return setTab(id);
    if (a === 'back') return back();
    if (a === 'gotab') return setTab(id);
    if (a === 'product') return go('product', { id });
    if (a === 'cart') return go('cart', { price: null, coupon: '' }), refreshPrice();
    if (a === 'addmoney') return go('addmoney', { method: S.d.payment_methods[0] && S.d.payment_methods[0].id });
    if (a === 'pmsel') { st.method = Number(id); return render(); }
    if (a === 'order') return go('order', { id });
    if (a === 'extrapage') return go('extrapage', { id });
    if (a === 'cat') { S.cat = id || null; S.q = ''; S.tab = 'products'; S.stack = []; return render(); }
    if (a === 'all') return setTab('products');
    if (a === 'searchbox') { S.tab = 'products'; S.stack = []; render(); const q = document.getElementById('q'); q && q.focus(); return; }
    if (a === 'hist') { S.q = id; return render(); }
    if (a === 'hidenotice') { S.noticeHidden = true; return render(); }
    if (a === 'link') return openLink(id);
    if (a === 'copy') { try { await navigator.clipboard.writeText(id); } catch { const t = document.createElement('textarea'); t.value = id; document.body.appendChild(t); t.select(); document.execCommand('copy'); t.remove(); } return toast('কপি হয়েছে ✓'); }
    if (a === 'banner') {
      const b = byId(el.dataset.t === 'pb' ? S.d.product_banners : S.d.banners, id); if (!b) return;
      if (b.link_type === 'product' && b.link_id) return go('product', { id: b.link_id });
      if (b.link_type === 'category' && b.link_id) { S.cat = String(b.link_id); S.tab = 'products'; S.stack = []; return render(); }
      if (b.link_url) return openLink(b.link_url); return;
    }
    if (a === 'addcart') { addCart(id); render(); return toast('কার্টে যোগ হয়েছে ✓'); }
    if (a === 'buynow') { S.cart = [{ id: Number(id), qty: 1 }]; saveCart(); go('cart', { price: null, coupon: '' }); return refreshPrice(); }
    if (a === 'qplus') { addCart(id); return refreshPrice(); }
    if (a === 'qminus') { const c = S.cart.find((x) => String(x.id) === id); if (c && c.qty > 1) c.qty--; saveCart(); return refreshPrice(); }
    if (a === 'rm') { S.cart = S.cart.filter((x) => String(x.id) !== id); saveCart(); return refreshPrice(); }
    if (a === 'applycp') { st.coupon = document.getElementById('cp').value.trim(); st.address = (document.getElementById('ad') || {}).value; st.phone = (document.getElementById('phn') || {}).value; return refreshPrice(); }
    if (a === 'reorder') { const o = byId(S.me.orders, id); (o.items || []).forEach((i) => byId(S.d.products, i.product_id) && addCart(i.product_id, i.qty)); go('cart', { price: null, coupon: '' }); return refreshPrice(); }
    if (a === 'share') { const p = byId(S.d.products, id); const url = location.origin; const text = `${p.name} — EntireBazar`; if (tg) return tg.openTelegramLink(`https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`); if (navigator.share) return navigator.share({ title: text, url }); return toast('শেয়ার সমর্থিত নয়', 1); }
    if (a === 'rate') { const r = document.getElementById('rate'); r.dataset.v = id; [...r.children].forEach((b, i) => b.classList.toggle('on', i < Number(id))); return; }
    if (a === 'sendreview') { await api('/review', 'POST', { product_id: id, rating: Number(document.getElementById('rate').dataset.v), text: document.getElementById('rtxt').value }); toast('রিভিউ জমা হয়েছে ✓'); await boot(true); return; }
    if (a === 'savephone') { const j = await api('/profile', 'POST', { phone: document.getElementById('ph').value }); S.user = j.user; return toast('সেভ হয়েছে ✓'); }
    if (a === 'readall') { await api('/notifications/read', 'POST'); await loadMe(); return render(); }
    if (a === 'submitdep') {
      el.disabled = true;
      try {
        let shot = null; const f = document.getElementById('dShot').files[0];
        if (f) { if (f.size > 5e6) throw new Error('ছবি ৫MB-এর কম হতে হবে'); const data = await new Promise((ok) => { const r = new FileReader(); r.onload = () => ok(r.result.split(',')[1]); r.readAsDataURL(f); }); shot = (await api('/upload', 'POST', { data, ext: f.name.split('.').pop() })).url; }
        await api('/deposit', 'POST', { method_id: id, amount: document.getElementById('dAmt').value, txid: document.getElementById('dTx').value, screenshot_url: shot });
        await loadMe(); toast('✅ রিকোয়েস্ট জমা হয়েছে। অ্যাডমিন যাচাই করবে।'); S.stack = []; S.tab = 'wallet'; render();
      } finally { el.disabled = false; }
      return;
    }
    if (a === 'confirm') {
      el.disabled = true;
      try {
        const j = await api('/checkout', 'POST', { items: S.cart.map((c) => ({ product_id: c.id, qty: c.qty })), coupon: st.coupon || '', address: (document.getElementById('ad') || {}).value || '', phone: (document.getElementById('phn') || {}).value || '' });
        S.cart = []; saveCart(); await boot(true); S.stack = [{ type: 'success', order: j.order }]; render();
      } finally { el.disabled = false; }
      return;
    }
  } catch (err) { toast(err.message, 1); }
});
document.addEventListener('input', (e) => {
  if (e.target.id === 'q') { S.q = e.target.value; clearTimeout(input.t); input.t = setTimeout(() => { if (S.q.length > 2) { const h2 = JSON.parse(localStorage.getItem('eb_hist') || '[]').filter((x) => x !== S.q); h2.unshift(S.q); localStorage.setItem('eb_hist', JSON.stringify(h2.slice(0, 6))); } }, 1500); render(); }
  if (e.target.id === 'dAmt') { const st = S.stack[S.stack.length - 1]; const m = byId(S.d.payment_methods, st.method); const v = Number(e.target.value); const c = document.getElementById('dCharge'); if (m && v > 0 && Number(m.charge_percent) > 0) { const ch = Math.round(v * m.charge_percent) / 100; c.style.display = 'block'; c.textContent = `চার্জ ${m.charge_percent}% = ${fm(ch)} · পাঠাতে হবে ${fm(v + ch)}`; } else c.style.display = 'none'; }
});
function input() {}

async function boot(soft) {
  if (!S.token) await login();
  try { await loadMe(); } catch (e) { await login(); await loadMe(); }
  S.d = await api('/bootstrap');
  document.title = S.d.settings.store_name || 'EntireBazar';
  S.cart = S.cart.filter((c) => byId(S.d.products, c.id));
  if (!soft) render(); else render();
}
$app.innerHTML = '<div class="loading">EntireBazar লোড হচ্ছে...</div>';
(async () => { try { await login(); await boot(); } catch (e) { $app.innerHTML = `<div class="empty" style="padding-top:30vh">${h(e.message)}<br><br>টেলিগ্রাম বটের মাধ্যমে অ্যাপ খুলুন।</div>`; } })();
