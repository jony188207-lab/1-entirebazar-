'use strict';
// ডাটাবেস লেয়ার: SUPABASE_URL থাকলে Supabase, না থাকলে মেমরি (শুধু টেস্ট/ডেমোর জন্য)
const URL_ = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const KEY = process.env.SUPABASE_SERVICE_KEY || '';
const useSupabase = !!(URL_ && KEY);

function fail(code) { const e = new Error(code); e.code = code; return e; }

/* ---------------- Supabase ---------------- */
async function sb(path, opts = {}) {
  const r = await fetch(`${URL_}/rest/v1/${path}`, {
    ...opts,
    headers: { apikey: KEY, Authorization: `Bearer ${KEY}`, 'Content-Type': 'application/json', Prefer: 'return=representation', ...(opts.headers || {}) },
  });
  const t = await r.text();
  let j = null; try { j = t ? JSON.parse(t) : null; } catch { j = null; }
  if (!r.ok) {
    if (r.status === 409 || (j && j.code === '23505')) throw fail('duplicate');
    const msg = (j && (j.message || j.hint)) || t || 'db_error';
    throw fail(String(msg).replace(/^.*?(insufficient_balance|out_of_stock|product_unavailable|already_processed|cannot_cancel|not_found).*$/s, '$1'));
  }
  return j;
}
const qs = (where = {}) => Object.entries(where).map(([k, v]) => v === null ? `${k}=is.null` : `${k}=eq.${encodeURIComponent(v)}`).join('&');

const supa = {
  async list(t, { where = {}, order, limit } = {}) {
    const p = ['select=*', qs(where)];
    if (order) p.push(`order=${order}`);
    if (limit) p.push(`limit=${limit}`);
    return (await sb(`${t}?${p.filter(Boolean).join('&')}`)) || [];
  },
  async get(t, id) { const r = await sb(`${t}?select=*&id=eq.${encodeURIComponent(id)}&limit=1`); return r && r[0] || null; },
  async insert(t, row) { const r = await sb(t, { method: 'POST', body: JSON.stringify(row) }); return r[0]; },
  async update(t, id, patch) { const r = await sb(`${t}?id=eq.${encodeURIComponent(id)}`, { method: 'PATCH', body: JSON.stringify(patch) }); return r && r[0] || null; },
  async remove(t, id) { await sb(`${t}?id=eq.${encodeURIComponent(id)}`, { method: 'DELETE' }); },
  async upsert(t, row) { const r = await sb(t, { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=representation' }, body: JSON.stringify(row) }); return r[0]; },
  async rpc(name, args) { return sb(`rpc/${name}`, { method: 'POST', body: JSON.stringify(args) }); },
  async upload(name, buf, type) {
    const r = await fetch(`${URL_}/storage/v1/object/media/${name}`, { method: 'POST', headers: { apikey: KEY, Authorization: `Bearer ${KEY}`, 'Content-Type': type, 'x-upsert': 'true' }, body: buf });
    if (!r.ok) throw fail('upload_failed');
    return `${URL_}/storage/v1/object/public/media/${name}`;
  },
};

/* ---------------- Memory (টেস্ট) ---------------- */
const T = {}; const SEQ = {};
const UNIQUE = { users: ['tg_id'], coupons: ['code'] };
const tbl = (t) => (T[t] ||= []);
const now = () => new Date().toISOString();
const clone = (x) => (x == null ? x : JSON.parse(JSON.stringify(x)));
function sortRows(rows, order) {
  if (!order) return rows;
  const [c, d] = order.split('.');
  return rows.sort((a, b) => ((a[c] > b[c]) - (a[c] < b[c])) * (d === 'desc' ? -1 : 1));
}
const defaults = { users: { balance: 0, total_deposit: 0, total_spent: 0, lang: 'bn' }, categories: { sort: 0, active: true }, products: { type: 'digital', stock: 0, images: [], sold: 0, status: 'published', price: 0, featured: false, trending: false, special_offer: false, recommended: false, popular: false }, banners: { sort: 0, active: true }, product_banners: { sort: 0, active: true }, extra_pages: { sort: 0, active: true, product_ids: [], buttons: [] }, payment_methods: { min_amount: 10, max_amount: 50000, charge_percent: 0, active: true, sort: 0 }, deposits: { status: 'pending', charge: 0 }, coupons: { used: 0, max_uses: 100, active: true }, reviews: { approved: true }, notifications: { read: false }, orders: { delivery: [] }, digital_stock: { used: false } };

const mem = {
  async list(t, { where = {}, order, limit } = {}) {
    let r = tbl(t).filter((row) => Object.entries(where).every(([k, v]) => (v === null ? row[k] == null : String(row[k]) === String(v))));
    r = sortRows(clone(r), order);
    return limit ? r.slice(0, limit) : r;
  },
  async get(t, id) { return clone(tbl(t).find((r) => String(r.id) === String(id))) || null; },
  async insert(t, row) {
    for (const c of UNIQUE[t] || []) if (tbl(t).some((r) => String(r[c]).toLowerCase() === String(row[c]).toLowerCase())) throw fail('duplicate');
    if (t === 'deposits' && tbl(t).some((r) => String(r.txid).toLowerCase() === String(row.txid).toLowerCase())) throw fail('duplicate');
    const o = { ...clone(defaults[t] || {}), ...clone(row), id: (SEQ[t] = (SEQ[t] || 0) + 1), created_at: now() };
    tbl(t).push(o); return clone(o);
  },
  async update(t, id, patch) { const r = tbl(t).find((x) => String(x.id) === String(id)); if (!r) return null; Object.assign(r, clone(patch)); return clone(r); },
  async remove(t, id) {
    T[t] = tbl(t).filter((r) => String(r.id) !== String(id));
    if (t === 'categories') T.categories = T.categories.filter((c) => String(c.parent_id) !== String(id));
  },
  async upsert(t, row) { const r = tbl(t).find((x) => x.id === row.id); if (r) { Object.assign(r, clone(row)); return clone(r); } tbl(t).push(clone(row)); return clone(row); },
  async upload(name, buf) {
    const fs = require('fs'); const path = require('path');
    const dir = path.join(__dirname, 'uploads'); fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, name), buf); return `/uploads/${name}`;
  },
  async rpc(name, a) {
    const byId = (t, id) => tbl(t).find((r) => String(r.id) === String(id));
    const ledger = (u, type, amount, ref, note) => tbl('ledger').push({ id: (SEQ.ledger = (SEQ.ledger || 0) + 1), user_id: u.id, type, amount, balance_after: u.balance, ref, note, created_at: now() });
    if (name === 'approve_deposit') {
      const d = byId('deposits', a.p_id); if (!d) throw fail('not_found');
      if (d.status !== 'pending') throw fail('already_processed');
      const u = byId('users', d.user_id); u.balance += d.amount; u.total_deposit += d.amount;
      ledger(u, 'deposit', d.amount, 'DEP' + d.id, `${d.method_name} / ${d.txid}`); d.status = 'approved'; return clone(d);
    }
    if (name === 'place_order') {
      const o = a.p_order; const u = byId('users', a.p_user);
      if (u.balance < o.total) throw fail('insufficient_balance');
      const snap = clone({ P: tbl('products'), S: tbl('digital_stock') });
      try {
        let allDigital = true; const keys = [];
        for (const it of o.items) {
          const p = byId('products', it.product_id);
          if (!p || p.status !== 'published') throw fail('product_unavailable');
          if (p.type === 'digital') {
            const free = tbl('digital_stock').filter((s) => s.product_id === p.id && !s.used).slice(0, it.qty);
            if (free.length < it.qty) throw fail('out_of_stock');
            free.forEach((s) => { s.used = true; keys.push({ product_id: p.id, name: p.name, content: s.content }); });
          } else { allDigital = false; if (p.stock < it.qty) throw fail('out_of_stock'); p.stock -= it.qty; }
          p.sold += it.qty;
        }
        u.balance -= o.total; u.total_spent += o.total;
        const row = await mem.insert('orders', { user_id: u.id, items: o.items, subtotal: o.subtotal, discount: o.discount, shipping: o.shipping, total: o.total, coupon: o.coupon || null, status: allDigital ? 'completed' : 'processing', payment: 'wallet', address: o.address, phone: o.phone, delivery: keys });
        const ord = byId('orders', row.id); ord.number = 'EB' + String(ord.id).padStart(6, '0');
        ledger(u, 'purchase', -o.total, ord.number, 'Order ' + ord.number);
        if (o.coupon) { const c = tbl('coupons').find((x) => x.code.toUpperCase() === o.coupon.toUpperCase()); if (c) c.used++; }
        return clone(ord);
      } catch (e) { T.products = snap.P; T.digital_stock = snap.S; throw e; }
    }
    if (name === 'cancel_order') {
      const o = byId('orders', a.p_id); if (!o) throw fail('not_found');
      if (!['pending', 'processing'].includes(o.status)) throw fail('cannot_cancel');
      const u = byId('users', o.user_id);
      o.items.forEach((it) => { const p = byId('products', it.product_id); if (p && p.type === 'physical') p.stock += it.qty; });
      u.balance += o.total; u.total_spent = Math.max(u.total_spent - o.total, 0);
      ledger(u, 'refund', o.total, o.number, 'Refund ' + o.number); o.status = 'cancelled'; return clone(o);
    }
    throw fail('unknown_rpc');
  },
};

const db = useSupabase ? supa : mem;
db.isSupabase = useSupabase;

// মেমরি মোডে শুরুর ক্যাটাগরি ও সেটিংস
if (!useSupabase) {
  (async () => {
    const dn = await mem.insert('categories', { name: 'Digital Network', sort: 1 });
    await mem.insert('categories', { name: 'Electronics', sort: 2 });
    await mem.insert('categories', { name: 'Clothing', sort: 3 });
    await mem.insert('categories', { name: 'Other Products', sort: 4 });
    for (const [i, n] of ['VPN', 'IP Address', 'Proxy', 'eSIM'].entries()) await mem.insert('categories', { name: n, parent_id: dn.id, sort: i + 1 });
    await mem.upsert('settings', { id: 'store_name', value: 'EntireBazar' });
    await mem.upsert('settings', { id: 'currency', value: '৳' });
    await mem.upsert('settings', { id: 'shipping_charge', value: 60 });
    await mem.upsert('settings', { id: 'notice', value: 'EntireBazar-এ স্বাগতম!' });
  })();
}
module.exports = db;
