# EntireBazar — টেলিগ্রাম মিনি অ্যাপ + অ্যাডমিন প্যানেল

কোনো npm প্যাকেজ লাগে না (শুধু Node.js 20+)। ডাটাবেস ও ছবি: Supabase (ফ্রি)। হোস্টিং: Render (ফ্রি)।

## ধাপ ১ — Supabase
1. supabase.com > New Project (ফ্রি)।
2. SQL Editor > New query > `schema.sql`-এর পুরোটা পেস্ট > Run।
3. Storage > New bucket > নাম `media` > **Public bucket** চালু।
4. Project Settings > API থেকে `Project URL` ও `service_role` key কপি করুন (service_role কাউকে দেবেন না)।

## ধাপ ২ — টেলিগ্রাম বট
1. @BotFather > /newbot > বট টোকেন কপি করুন।
2. (ঐচ্ছিক) আপনার Chat ID জানতে @userinfobot-এ /start দিন → `ADMIN_CHAT_ID`।

## ধাপ ৩ — GitHub + Render
1. এই ফোল্ডার GitHub-এ একটি প্রাইভেট রিপোতে আপলোড করুন (`.env` আপলোড করবেন না)।
2. render.com > New > Web Service > রিপো বাছুন। Runtime: Node, Build Command: ফাঁকা, Start Command: `node server.js`।
3. Environment-এ `.env.example`-এর সব মান বসান (WEBAPP_URL পরে দেবেন)।
4. Deploy শেষে পাওয়া লিংক (https://xxxx.onrender.com) `WEBAPP_URL`-এ বসিয়ে Save করুন।

## ধাপ ৪ — বটে মিনি অ্যাপ সংযোগ
কম্পিউটারে (Node 20+): `.env` ফাইলে মান বসিয়ে `node --env-file=.env setup-bot.js`
অথবা BotFather > /mybots > আপনার বট > Bot Settings > Menu Button > আপনার WEBAPP_URL।

## ব্যবহার
- কাস্টমার: বটে /start বা মেনু বাটন চাপলেই অ্যাপ খুলবে। লগইন/সাইনআপ স্বয়ংক্রিয়, টেলিগ্রামের নাম/ছবি দিয়ে।
- অ্যাডমিন: `আপনার-লিংক/admin` → ADMIN_PASSWORD দিয়ে লগইন।
- প্রথমে অ্যাডমিনে: Payment Methods যোগ (আপনার নিজের bKash/Nagad নম্বর) → Products → Digital Stock।

## বট নোটিফিকেশন কখন যায়
- মিনি অ্যাপে প্রথম ঢুকলে ও পরে ৬ ঘণ্টা পর পর ঢুকলে
- ডিপোজিট রিকোয়েস্ট জমা / অনুমোদন / বাতিল
- অর্ডার হলে ও অর্ডার সফল হলে (ডিজিটাল পণ্যের কী সহ)
- শিপ হলে, বাতিল-রিফান্ড হলে
- নোট: টেলিগ্রামের নিয়মে ব্যবহারকারী বটকে অন্তত একবার /start বা মেনু বাটন দিয়ে খুললে তবেই বট মেসেজ পাঠাতে পারে।

## লোকাল টেস্ট
`npm test` (মেমরি ডাটাবেসে ৪৫টি টেস্ট)।
