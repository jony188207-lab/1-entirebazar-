-- EntireBazar — Supabase (PostgreSQL) schema
-- Supabase Dashboard > SQL Editor এ পুরোটা পেস্ট করে Run করুন।

create table if not exists users (
  id bigint generated always as identity primary key,
  tg_id bigint unique not null,
  first_name text, last_name text, username text, photo_url text, phone text,
  lang text default 'bn',
  balance numeric(12,2) not null default 0 check (balance >= 0),
  total_deposit numeric(12,2) not null default 0,
  total_spent numeric(12,2) not null default 0,
  last_notified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists categories (
  id bigint generated always as identity primary key,
  parent_id bigint references categories(id) on delete cascade,
  name text not null, description text, icon_url text, image_url text, cover_url text,
  sort int not null default 0, active boolean not null default true
);

create table if not exists products (
  id bigint generated always as identity primary key,
  category_id bigint references categories(id) on delete set null,
  name text not null, description text,
  price numeric(12,2) not null default 0, discount_price numeric(12,2),
  images jsonb not null default '[]', video_url text,
  type text not null default 'digital' check (type in ('digital','physical')),
  stock int not null default 0,
  featured boolean not null default false, trending boolean not null default false,
  special_offer boolean not null default false, recommended boolean not null default false,
  popular boolean not null default false,
  sold int not null default 0,
  status text not null default 'published' check (status in ('draft','published')),
  created_at timestamptz not null default now()
);

create table if not exists digital_stock (
  id bigint generated always as identity primary key,
  product_id bigint not null references products(id) on delete cascade,
  content text not null, used boolean not null default false
);
create index if not exists digital_stock_p on digital_stock(product_id, used);

create table if not exists banners (
  id bigint generated always as identity primary key,
  title text, description text, image_url text,
  link_type text default 'none', link_id bigint, link_url text,
  start_at timestamptz, end_at timestamptz,
  sort int not null default 0, active boolean not null default true
);
create table if not exists product_banners (like banners including all);

create table if not exists extra_pages (
  id bigint generated always as identity primary key,
  title text not null, icon text, image_url text, banner_url text,
  description text, content text,
  category_id bigint, product_ids jsonb not null default '[]',
  buttons jsonb not null default '[]',
  sort int not null default 0, active boolean not null default true
);

create table if not exists payment_methods (
  id bigint generated always as identity primary key,
  name text not null, logo_url text, number text, account_type text, instructions text,
  min_amount numeric(12,2) not null default 10, max_amount numeric(12,2) not null default 50000,
  charge_percent numeric(5,2) not null default 0,
  active boolean not null default true, sort int not null default 0
);

create table if not exists deposits (
  id bigint generated always as identity primary key,
  user_id bigint not null references users(id),
  method_id bigint references payment_methods(id),
  method_name text,
  amount numeric(12,2) not null check (amount > 0), charge numeric(12,2) not null default 0,
  txid text not null, screenshot_url text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  admin_note text, created_at timestamptz not null default now()
);
create unique index if not exists deposits_txid_uniq on deposits (lower(txid));

create table if not exists ledger (
  id bigint generated always as identity primary key,
  user_id bigint not null references users(id),
  type text not null, amount numeric(12,2) not null, balance_after numeric(12,2) not null,
  ref text, note text, created_at timestamptz not null default now()
);

create table if not exists orders (
  id bigint generated always as identity primary key,
  number text, user_id bigint not null references users(id),
  items jsonb not null, subtotal numeric(12,2), discount numeric(12,2) default 0,
  shipping numeric(12,2) default 0, total numeric(12,2) not null,
  coupon text, status text not null default 'pending',
  payment text default 'wallet', address text, phone text,
  delivery jsonb not null default '[]', tracking text,
  created_at timestamptz not null default now()
);

create table if not exists coupons (
  id bigint generated always as identity primary key,
  code text unique not null, percent numeric(5,2) not null,
  max_uses int not null default 100, used int not null default 0,
  active boolean not null default true
);

create table if not exists reviews (
  id bigint generated always as identity primary key,
  product_id bigint not null references products(id) on delete cascade,
  user_id bigint not null references users(id),
  user_name text, rating int not null check (rating between 1 and 5), text text,
  approved boolean not null default true, created_at timestamptz not null default now()
);

create table if not exists notifications (
  id bigint generated always as identity primary key,
  user_id bigint not null references users(id),
  title text, body text, read boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists settings (id text primary key, value jsonb);

-- সার্ভার service_role key দিয়ে কাজ করে; anon key দিয়ে কেউ সরাসরি ডাটা পড়তে পারবে না
do $$ declare t text; begin
  foreach t in array array['users','categories','products','digital_stock','banners','product_banners','extra_pages','payment_methods','deposits','ledger','orders','coupons','reviews','notifications','settings'] loop
    execute format('alter table %I enable row level security', t);
  end loop;
end $$;

-- ===== অ্যাটমিক ফাংশন (ওয়ালেটের টাকা ও স্টক নিরাপদ রাখে) =====

create or replace function approve_deposit(p_id bigint) returns deposits
language plpgsql as $$
declare d deposits; u users;
begin
  select * into d from deposits where id = p_id for update;
  if d.id is null then raise exception 'not_found'; end if;
  if d.status <> 'pending' then raise exception 'already_processed'; end if;
  select * into u from users where id = d.user_id for update;
  update users set balance = balance + d.amount, total_deposit = total_deposit + d.amount where id = u.id;
  insert into ledger(user_id, type, amount, balance_after, ref, note)
    values (u.id, 'deposit', d.amount, u.balance + d.amount, 'DEP' || d.id, d.method_name || ' / ' || d.txid);
  update deposits set status = 'approved' where id = d.id returning * into d;
  return d;
end $$;

create or replace function place_order(p_user bigint, p_order jsonb) returns orders
language plpgsql as $$
declare u users; o orders; it jsonb; p products; k record;
  keys jsonb := '[]'::jsonb; total numeric := (p_order->>'total')::numeric;
  all_digital boolean := true; qty int; got int;
begin
  select * into u from users where id = p_user for update;
  if u.balance < total then raise exception 'insufficient_balance'; end if;
  for it in select value from jsonb_array_elements(p_order->'items') loop
    qty := (it->>'qty')::int;
    select * into p from products where id = (it->>'product_id')::bigint for update;
    if p.id is null or p.status <> 'published' then raise exception 'product_unavailable'; end if;
    if p.type = 'digital' then
      got := 0;
      for k in select id, content from digital_stock where product_id = p.id and used = false order by id limit qty for update skip locked loop
        update digital_stock set used = true where id = k.id;
        keys := keys || jsonb_build_array(jsonb_build_object('product_id', p.id, 'name', p.name, 'content', k.content));
        got := got + 1;
      end loop;
      if got < qty then raise exception 'out_of_stock'; end if;
    else
      all_digital := false;
      if p.stock < qty then raise exception 'out_of_stock'; end if;
      update products set stock = stock - qty where id = p.id;
    end if;
    update products set sold = sold + qty where id = p.id;
  end loop;
  insert into orders(user_id, items, subtotal, discount, shipping, total, coupon, status, payment, address, phone, delivery)
    values (p_user, p_order->'items', (p_order->>'subtotal')::numeric, (p_order->>'discount')::numeric,
            (p_order->>'shipping')::numeric, total, nullif(p_order->>'coupon',''),
            case when all_digital then 'completed' else 'processing' end, 'wallet',
            p_order->>'address', p_order->>'phone', keys)
    returning * into o;
  update orders set number = 'EB' || lpad(o.id::text, 6, '0') where id = o.id returning * into o;
  update users set balance = balance - total, total_spent = total_spent + total where id = p_user;
  insert into ledger(user_id, type, amount, balance_after, ref, note)
    values (p_user, 'purchase', -total, u.balance - total, o.number, 'Order ' || o.number);
  if nullif(p_order->>'coupon','') is not null then
    update coupons set used = used + 1 where upper(code) = upper(p_order->>'coupon');
  end if;
  return o;
end $$;

create or replace function cancel_order(p_id bigint) returns orders
language plpgsql as $$
declare o orders; u users; it jsonb;
begin
  select * into o from orders where id = p_id for update;
  if o.id is null then raise exception 'not_found'; end if;
  if o.status not in ('pending','processing') then raise exception 'cannot_cancel'; end if;
  select * into u from users where id = o.user_id for update;
  for it in select value from jsonb_array_elements(o.items) loop
    update products set stock = stock + (it->>'qty')::int where id = (it->>'product_id')::bigint and type = 'physical';
  end loop;
  update users set balance = balance + o.total, total_spent = greatest(total_spent - o.total, 0) where id = u.id;
  insert into ledger(user_id, type, amount, balance_after, ref, note)
    values (u.id, 'refund', o.total, u.balance + o.total, o.number, 'Refund ' || o.number);
  update orders set status = 'cancelled' where id = o.id returning * into o;
  return o;
end $$;

-- ===== শুরুর ক্যাটাগরি (পরে অ্যাডমিন প্যানেল থেকে বাড়ানো/মোছা যাবে) =====
insert into categories(name, sort) select * from (values
  ('Digital Network',1),('Electronics',2),('Clothing',3),('Other Products',4)) v(n,s)
  where not exists (select 1 from categories);
insert into categories(parent_id, name, sort)
  select (select id from categories where name='Digital Network' limit 1), n, s from (values
  ('VPN',1),('IP Address',2),('Proxy',3),('eSIM',4)) v(n,s)
  where not exists (select 1 from categories where name='VPN');

insert into settings(id, value) values
  ('store_name','"EntireBazar"'),('currency','"৳"'),('shipping_charge','60'),
  ('notice','"EntireBazar-এ স্বাগতম! নতুন অফারের জন্য চোখ রাখুন।"'),
  ('support_url','""')
on conflict (id) do nothing;

-- Storage: Dashboard > Storage > New bucket > নাম "media" > Public bucket চালু করুন।
