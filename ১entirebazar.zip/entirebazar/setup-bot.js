'use strict';
// একবার চালান: node --env-file=.env setup-bot.js
const { BOT_TOKEN, WEBAPP_URL, WEBHOOK_SECRET } = process.env;
if (!BOT_TOKEN || !WEBAPP_URL) { console.error('BOT_TOKEN ও WEBAPP_URL .env-এ দিন'); process.exit(1); }
const call = async (m, b) => (await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${m}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(b) })).json();
(async () => {
  console.log('মেনু বাটন:', JSON.stringify(await call('setChatMenuButton', { menu_button: { type: 'web_app', text: 'EntireBazar', web_app: { url: WEBAPP_URL } } })));
  if (WEBHOOK_SECRET) console.log('ওয়েবহুক:', JSON.stringify(await call('setWebhook', { url: `${WEBAPP_URL}/api/telegram/${WEBHOOK_SECRET}`, allowed_updates: ['message'] })));
  else console.log('WEBHOOK_SECRET দেননি, তাই /start-এর ওয়েবহুক সেট হয়নি (ঐচ্ছিক)');
})();
