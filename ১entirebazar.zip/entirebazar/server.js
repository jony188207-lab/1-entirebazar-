'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const db = require('./db');

const PORT = process.env.PORT || 3000;
const BOT_TOKEN = process.env.BOT_TOKEN || '';
const APP_SECRET = process.env.APP_SECRET || '';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';
const WEBAPP_URL = (process.env.WEBAPP_URL || '').replace(/\/$/, '');
const ADMIN_CHAT_ID = process.env.ADMIN_CHAT_ID || '';
const DEV_MODE = process.env.DEV_MODE === '1';
const WEBHOOK_SECRET = process.env.WEBHOOK_SECRET || '';

if (!APP_SECRET || APP_SECRET.length < 16) { console.error('APP_SECRET (কমপক্ষে ১৬ অক্ষর) .env-এ দিন'); process.exit(1); }
if (!ADMIN_PASSWORD || ADMIN_PASSWORD.length < 8) { console.error('ADMIN_PASSWORD (কমপক্ষে ৮ অক্ষর) .env-এ দিন'); process.exit(1); }

/* ---------- টোকেন ---------- */
const b64 = (s) => Buffer.from(s).toString('base64url');
const hmac = (k, d) => crypto.createHmac('sha256', k).update(d).digest();
function sign(payload, hours = 24 * 7) {
  const body = b64(JSON.stringify({ ...payload, exp: Date.now() + hours * 3600e3 }));
  return `${body}.${hmac(APP_SECRET, body).toString('base64url')}`;
}
function verify(tok) {
  if (!tok || typeof tok !== 'string') return null;
  const [body, sig] = tok.split('.');
  if (!body || !sig) return null;
  const good = hmac(APP_SECRET, body).toString('base64url');
  if (sig.length !== good.length || !crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(good))) return null;
  try { const p = JSON.parse(Buffer.from(body, 'base64url').toString()); return p.exp > Date.now() ? p : null; } catch { return null; }
}

/* ---------- টেলিগ্রাম ---------- */
function verifyInitData(initData) {
  const p = new URLSearchParams(initData);
  const hash = p.get('hash'); if (!hash) return null;
  p.delete('hash');
  const check = [...p.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([k, v]) => `${k}=${v}`).join('\n');
  const secret = hmac('WebAppData', BOT_TOKEN);
  const calc = crypto.createHmac('sha256', secret).update(check).digest('hex');
  if (calc.length !== hash.length || !crypto.timingSafeEqual(Buffer.from(calc), Buffer.from(hash))) return null;
  if (Date.now() / 1000 - Number(p.get('auth_date') || 0) > 86400) return null;
  try { return JSON.parse(p.get('user')); } catch { return null; }
}
const esc = (s) => String(s ?? '').replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c]));
async function tg(method, body) {
  if (!BOT_TOKEN) return null;
  try {
    const r = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    return await r.json();
  } catch (e) { console.error('telegram error', e.message); return null; }
}
async function notify(user, title, body, { telegram = true } = {}) {
  try { await db.insert('notifications', { user_id: user.id, title, body }); } catch (e) { console.error(e.message); }
  if (telegram) await tg('sendMessage', { chat_id: user.tg_id, text: `<b>${esc(title)}</b>\n${esc(body)}`, parse_mode: 'HTML', ...(WEBAPP_URL ? { reply_markup: { inline_keyboard: [[{ text: '🛍 EntireBazar খুলুন', web_app: { url: WEBAPP_URL } }]] } } : {}) });
}
const adminAlert = (text) => ADMIN_CHAT_ID && tg('sendMessage', { chat_id: ADMIN_CHAT_ID, text, parse_mode: 'HTML' });

/* ---------- হেল্পার ---------- */
const send = (res, code, data, type = 'application/json') => { res.writeHead(code, { 'Content-Type': type + '; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }); res.end(type === 'application/json' ? JSON.stringify(data) : data); };
const bad = (res, msg, code = 400) => send(res, code, { error: msg });
async function body(req, max = 8e6) {
  return new Promise((ok, no) => {
    let n = 0; const c = [];
    req.on('data', (d) => { n += d.length; if (n > max) { no(new Error('too_large')); req.destroy(); } else c.push(d); });
    req.on('end', () => { try { ok(c.length ? JSON.parse(Buffer.concat(c).toString()) : {}); } catch { no(new Error('bad_json')); } });
    req.on('error', no);
  });
}
const num = (v, d = 0) => { const n = Number(v); return Number.isFinite(n) ? n : d; };
const money = (n) => Math.round(num(n) * 100) / 100;
const price = (p) => (p.discount_price != null && num(p.discount_price) > 0 && num(p.discount_price) < num(p.price) ? num(p.discount_price) : num(p.price));
const inWindow = (b) => (!b.start_at || new Date(b.start_at) <= new Date()) && (!b.end_at || new Date(b.end_at) >= new Date());
async function settings() { const rows = await db.list('settings'); const o = {}; rows.forEach((r) => (o[r.id] = r.value)); return o; }
const publicUser = (u) => ({ id: u.id, first_name: u.first_name, last_name: u.last_name, username: u.username, photo_url: u.photo_url, phone: u.phone, balance: u.balance, total_deposit: u.total_deposit, total_spent: u.total_spent });
const bearer = (req) => (req.headers.authorization || '').replace(/^Bearer /, '');
const rate = new Map();
function limited(key, max, ms) { const n = Date.now(); const a = (rate.get(key) || []).filter((t) => n - t < ms); a.push(n); rate.set(key, a); return a.length > max; }

/* ---------- আপলোড ---------- */
const EXT = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp', mp4: 'video/mp4' };
async function upload(b, { imagesOnly }) {
  const ext = String(b.ext || '').toLowerCase().replace('.', '');
  if (!EXT[ext] || (imagesOnly && ext === 'mp4')) throw new Error('invalid_file_type');
  const buf = Buffer.from(String(b.data || ''), 'base64');
  if (!buf.length || buf.length > 6e6) throw new Error('invalid_file_size');
  return { url: await db.upload(`${Date.now()}-${crypto.randomBytes(5).toString('hex')}.${ext}`, buf, EXT[ext]) };
}

/* ---------- কাস্টমার API ---------- */
async function userFrom(req) {
  const p = verify(bearer(req)); if (!p || !p.uid) return null;
  return db.get('users', p.uid);
}

async function handleAuth(req, res) {
  const b = await body(req);
  let tu = null;
  if (BOT_TOKEN && b.initData) tu = verifyInitData(String(b.initData));
  if (!tu && DEV_MODE && b.dev) tu = { id: num(b.dev.id), first_name: b.dev.first_name || 'Dev', username: b.dev.username };
  if (!tu || !tu.id) return bad(res, 'টেলিগ্রাম থেকে অ্যাপ খুলুন (লগইন যাচাই ব্যর্থ)', 401);
  let [u] = await db.list('users', { where: { tg_id: tu.id }, limit: 1 });
  const fresh = { first_name: tu.first_name || '', last_name: tu.last_name || '', username: tu.username || '', photo_url: tu.photo_url || '' };
  let isNew = false;
  if (!u) {
    try { u = await db.insert('users', { tg_id: tu.id, ...fresh }); isNew = true; }
    catch (e) { if (e.code !== 'duplicate') throw e; [u] = await db.list('users', { where: { tg_id: tu.id }, limit: 1 }); }
  } else u = await db.update('users', u.id, fresh);
  const cfg = await settings();
  const name = u.first_name || u.username || 'বন্ধু';
  const last = u.last_notified_at ? new Date(u.last_notified_at).getTime() : 0;
  if (isNew || Date.now() - last > 6 * 3600e3) {
    await db.update('users', u.id, { last_notified_at: new Date().toISOString() });
    notify(u, isNew ? '🎉 স্বাগতম!' : '👋 আবার স্বাগতম!', `${name}, ${cfg.store_name || 'EntireBazar'}-এ ${isNew ? 'আপনার অ্যাকাউন্ট তৈরি হয়েছে' : 'আপনাকে দেখে ভালো লাগলো'}। আপনার ব্যালেন্স: ${cfg.currency || '৳'}${u.balance}`);
    if (isNew) adminAlert(`🆕 নতুন কাস্টমার: ${esc(name)} @${esc(u.username || '-')}`);
  }
  send(res, 200, { token: sign({ uid: u.id }), user: publicUser(u) });
}

async function handleBootstrap(req, res) {
  const [cfg, categories, banners, pbanners, products, methods, pages, reviews] = await Promise.all([
    settings(),
    db.list('categories', { where: { active: true }, order: 'sort.asc' }),
    db.list('banners', { where: { active: true }, order: 'sort.asc' }),
    db.list('product_banners', { where: { active: true }, order: 'sort.asc' }),
    db.list('products', { where: { status: 'published' }, order: 'id.desc', limit: 500 }),
    db.list('payment_methods', { where: { active: true }, order: 'sort.asc' }),
    db.list('extra_pages', { where: { active: true }, order: 'sort.asc' }),
    db.list('reviews', { where: { approved: true }, order: 'id.desc', limit: 20 }),
  ]);
  const stockRows = (await db.list('digital_stock', { where: { used: false } })).reduce((m, s) => ((m[s.product_id] = (m[s.product_id] || 0) + 1), m), {});
  send(res, 200, {
    settings: cfg, categories,
    banners: banners.filter(inWindow), product_banners: pbanners.filter(inWindow),
    products: products.map((p) => ({ ...p, final_price: price(p), available: p.type === 'digital' ? (stockRows[p.id] || 0) : p.stock })),
    payment_methods: methods, extra_pages: pages, reviews,
  });
}

async function handleMe(req, res, u) {
  const [ledger, deposits, orders, notes] = await Promise.all([
    db.list('ledger', { where: { user_id: u.id }, order: 'id.desc', limit: 100 }),
    db.list('deposits', { where: { user_id: u.id }, order: 'id.desc', limit: 50 }),
    db.list('orders', { where: { user_id: u.id }, order: 'id.desc', limit: 50 }),
    db.list('notifications', { where: { user_id: u.id }, order: 'id.desc', limit: 30 }),
  ]);
  send(res, 200, { user: publicUser(u), ledger, deposits, orders, notifications: notes });
}

async function handleDeposit(req, res, u) {
  if (limited('dep' + u.id, 10, 3600e3)) return bad(res, 'অনেক বেশি অনুরোধ, কিছুক্ষণ পরে চেষ্টা করুন', 429);
  const b = await body(req);
  const m = await db.get('payment_methods', b.method_id);
  if (!m || !m.active) return bad(res, 'পেমেন্ট মেথড পাওয়া যায়নি');
  const amount = money(b.amount);
  if (amount < num(m.min_amount) || amount > num(m.max_amount)) return bad(res, `এই মেথডে সর্বনিম্ন ${m.min_amount} ও সর্বোচ্চ ${m.max_amount} টাকা`);
  const txid = String(b.txid || '').trim();
  if (!/^[A-Za-z0-9\-_]{4,40}$/.test(txid)) return bad(res, 'সঠিক Transaction ID দিন (৪–৪০ অক্ষর/সংখ্যা)');
  const charge = money((amount * num(m.charge_percent)) / 100);
  try {
    const d = await db.insert('deposits', { user_id: u.id, method_id: m.id, method_name: m.name, amount, charge, txid, screenshot_url: b.screenshot_url || null, status: 'pending' });
    notify(u, '⏳ ডিপোজিট রিকোয়েস্ট জমা হয়েছে', `${amount} টাকা (${m.name}) যাচাইয়ের অপেক্ষায় আছে।`);
    adminAlert(`💰 নতুন ডিপোজিট: ${amount} টাকা\n${esc(m.name)} | TxID: ${esc(txid)}\nগ্রাহক: ${esc(u.first_name)} @${esc(u.username || '-')}`);
    send(res, 200, { deposit: d });
  } catch (e) { if (e.code === 'duplicate') return bad(res, 'এই Transaction ID আগেই ব্যবহার করা হয়েছে'); throw e; }
}

async function calcCart(items, couponCode) {
  if (!Array.isArray(items) || !items.length || items.length > 30) throw new Error('কার্ট খালি');
  const lines = []; let subtotal = 0; let physical = false;
  for (const it of items) {
    const p = await db.get('products', it.product_id); const qty = Math.floor(num(it.qty));
    if (!p || p.status !== 'published' || qty < 1 || qty > 20) throw new Error('পণ্য পাওয়া যায়নি');
    const pr = price(p); subtotal += pr * qty; if (p.type === 'physical') physical = true;
    lines.push({ product_id: p.id, name: p.name, price: pr, qty, type: p.type, image: (p.images || [])[0] || null });
  }
  let discount = 0; let coupon = '';
  if (couponCode) {
    const [c] = await db.list('coupons', { where: { code: String(couponCode).toUpperCase() }, limit: 1 });
    if (!c || !c.active || c.used >= c.max_uses) throw new Error('কুপন সঠিক নয় বা মেয়াদ শেষ');
    discount = money((subtotal * num(c.percent)) / 100); coupon = c.code;
  }
  const cfg = await settings();
  const shipping = physical ? num(cfg.shipping_charge) : 0;
  subtotal = money(subtotal);
  return { items: lines, subtotal, discount, shipping, total: money(subtotal - discount + shipping), coupon, physical };
}

async function handleCheckout(req, res, u) {
  if (limited('chk' + u.id, 20, 3600e3)) return bad(res, 'অনেক বেশি অনুরোধ', 429);
  const b = await body(req);
  let c; try { c = await calcCart(b.items, b.coupon); } catch (e) { return bad(res, e.message); }
  const address = String(b.address || '').trim().slice(0, 300); const phone = String(b.phone || u.phone || '').trim().slice(0, 20);
  if (c.physical && (address.length < 8 || !/^[0-9+\-\s]{8,20}$/.test(phone))) return bad(res, 'ফিজিক্যাল পণ্যের জন্য ঠিকানা ও ফোন নম্বর দিন');
  try {
    const o = await db.rpc('place_order', { p_user: u.id, p_order: { ...c, address, phone } });
    const order = Array.isArray(o) ? o[0] : o;
    if (phone && phone !== u.phone) db.update('users', u.id, { phone });
    const fresh = await db.get('users', u.id);
    notify(fresh, '🛒 অর্ডার গ্রহণ করা হয়েছে', `অর্ডার ${order.number} | মোট ${order.total} টাকা। ব্যালেন্স: ${fresh.balance} টাকা`);
    adminAlert(`🛒 নতুন অর্ডার ${order.number} — ${order.total} টাকা\nগ্রাহক: ${esc(u.first_name)} @${esc(u.username || '-')}`);
    if (order.status === 'completed') {
      const keys = (order.delivery || []).map((k) => `• ${esc(k.name)}: <code>${esc(k.content)}</code>`).join('\n');
      await notify(fresh, '✅ অর্ডার সফল হয়েছে', `অর্ডার ${order.number} সম্পন্ন।`, { telegram: false });
      await tg('sendMessage', { chat_id: u.tg_id, parse_mode: 'HTML', text: `<b>✅ অর্ডার সফল!</b>\nঅর্ডার: ${order.number}\n\n<b>আপনার ডিজিটাল পণ্য:</b>\n${keys}` });
    }
    send(res, 200, { order });
  } catch (e) {
    const m = { insufficient_balance: 'ওয়ালেটে পর্যাপ্ত ব্যালেন্স নেই। Add Money করুন।', out_of_stock: 'স্টক শেষ বা অপর্যাপ্ত', product_unavailable: 'পণ্যটি এখন পাওয়া যাচ্ছে না' };
    if (m[e.code || e.message]) return bad(res, m[e.code || e.message]);
    throw e;
  }
}

async function handleReview(req, res, u) {
  const b = await body(req);
  const rating = Math.floor(num(b.rating)); if (rating < 1 || rating > 5) return bad(res, 'রেটিং ১–৫ হতে হবে');
  const orders = await db.list('orders', { where: { user_id: u.id } });
  const bought = orders.some((o) => ['completed', 'processing'].includes(o.status) && (o.items || []).some((i) => String(i.product_id) === String(b.product_id)));
  if (!bought) return bad(res, 'শুধু ক্রেতারা রিভিউ দিতে পারেন (Verified Purchase)');
  const r = await db.insert('reviews', { product_id: b.product_id, user_id: u.id, user_name: u.first_name || u.username || 'Customer', rating, text: String(b.text || '').slice(0, 500) });
  send(res, 200, { review: r });
}

async function customerApi(req, res, url) {
  const p = url.pathname;
  if (p === '/api/auth' && req.method === 'POST') return handleAuth(req, res);
  if (p === '/api/bootstrap' && req.method === 'GET') return handleBootstrap(req, res);
  const u = await userFrom(req);
  if (!u) return bad(res, 'লগইন প্রয়োজন', 401);
  if (p === '/api/me') return handleMe(req, res, u);
  if (p === '/api/deposit' && req.method === 'POST') return handleDeposit(req, res, u);
  if (p === '/api/checkout' && req.method === 'POST') return handleCheckout(req, res, u);
  if (p === '/api/review' && req.method === 'POST') return handleReview(req, res, u);
  if (p === '/api/upload' && req.method === 'POST') { if (limited('up' + u.id, 15, 3600e3)) return bad(res, 'অনেক বেশি আপলোড', 429); return send(res, 200, await upload(await body(req), { imagesOnly: true })); }
  if (p === '/api/cart/price' && req.method === 'POST') { const b = await body(req); try { return send(res, 200, await calcCart(b.items, b.coupon)); } catch (e) { return bad(res, e.message); } }
  if (p === '/api/profile' && req.method === 'POST') { const b = await body(req); const phone = String(b.phone || '').slice(0, 20); const nu = await db.update('users', u.id, { phone }); return send(res, 200, { user: publicUser(nu) }); }
  if (p === '/api/notifications/read' && req.method === 'POST') { const ns = await db.list('notifications', { where: { user_id: u.id, read: false } }); await Promise.all(ns.map((n) => db.update('notifications', n.id, { read: true }))); return send(res, 200, { ok: true }); }
  return bad(res, 'not_found', 404);
}

/* ---------- অ্যাডমিন API ---------- */
const CRUD = ['categories', 'products', 'banners', 'product_banners', 'extra_pages', 'payment_methods', 'coupons', 'reviews'];
const READONLY = ['deposits', 'orders', 'users', 'ledger'];
const BOOL = ['active', 'featured', 'trending', 'special_offer', 'recommended', 'popular', 'approved'];
const NUMS = ['price', 'discount_price', 'stock', 'sort', 'min_amount', 'max_amount', 'charge_percent', 'percent', 'max_uses', 'parent_id', 'category_id', 'link_id'];
const JSONS = ['images', 'product_ids', 'buttons'];
function clean(t, b) {
  const o = {};
  for (const [k, v] of Object.entries(b)) {
    if (['id', 'created_at', 'used', 'sold'].includes(k)) continue;
    if (BOOL.includes(k)) o[k] = v === true || v === 'true';
    else if (NUMS.includes(k)) o[k] = v === '' || v == null ? null : num(v);
    else if (JSONS.includes(k)) o[k] = typeof v === 'string' ? (() => { try { return JSON.parse(v); } catch { return []; } })() : v;
    else if (['start_at', 'end_at'].includes(k)) o[k] = v ? new Date(v).toISOString() : null;
    else o[k] = v;
  }
  if (t === 'coupons' && o.code) o.code = String(o.code).toUpperCase().trim();
  return o;
}

async function adminApi(req, res, url) {
  const p = url.pathname;
  if (p === '/api/admin/login' && req.method === 'POST') {
    if (limited('login' + req.socket.remoteAddress, 8, 600e3)) return bad(res, 'অনেকবার ভুল, ১০ মিনিট পরে চেষ্টা করুন', 429);
    const b = await body(req);
    const a = Buffer.from(String(b.password || '')); const z = Buffer.from(ADMIN_PASSWORD);
    if (a.length !== z.length || !crypto.timingSafeEqual(a, z)) return bad(res, 'পাসওয়ার্ড ভুল', 401);
    return send(res, 200, { token: sign({ admin: true }, 12) });
  }
  const t = verify(bearer(req)); if (!t || !t.admin) return bad(res, 'অ্যাডমিন লগইন প্রয়োজন', 401);
  const seg = p.split('/').slice(3); // after /api/admin
  const [name, id, action] = seg;

  if (name === 'stats') {
    const [users, orders, products, deposits] = await Promise.all([db.list('users'), db.list('orders'), db.list('products'), db.list('deposits')]);
    const ok = orders.filter((o) => o.status !== 'cancelled');
    const days = {}; ok.forEach((o) => { const d = String(o.created_at).slice(0, 10); days[d] = money((days[d] || 0) + num(o.total)); });
    return send(res, 200, { total_sales: ok.length, total_revenue: money(ok.reduce((s, o) => s + num(o.total), 0)), customers: users.length, products: products.length, orders: orders.length, pending_deposits: deposits.filter((d) => d.status === 'pending').length, daily: Object.entries(days).sort().slice(-14), recent: orders.slice(-8).reverse() });
  }
  if (name === 'settings') {
    if (req.method === 'GET') return send(res, 200, await settings());
    const b = await body(req);
    for (const k of ['store_name', 'currency', 'shipping_charge', 'notice', 'support_url']) if (k in b) await db.upsert('settings', { id: k, value: k === 'shipping_charge' ? num(b[k]) : String(b[k]) });
    return send(res, 200, await settings());
  }
  if (name === 'upload' && req.method === 'POST') return send(res, 200, await upload(await body(req), { imagesOnly: false }));

  if (name === 'stock') {
    if (req.method === 'POST') {
      const b = await body(req); const lines = String(b.lines || '').split('\n').map((s) => s.trim()).filter(Boolean);
      if (!b.product_id || !lines.length) return bad(res, 'পণ্য ও কী/লাইন দিন');
      for (const content of lines) await db.insert('digital_stock', { product_id: b.product_id, content });
      return send(res, 200, { added: lines.length });
    }
    const rows = await db.list('digital_stock', { where: id ? { product_id: id } : {}, order: 'id.desc', limit: 300 });
    return send(res, 200, rows);
  }

  if (name === 'deposits' && id && action) {
    const d = await db.get('deposits', id); if (!d) return bad(res, 'not_found', 404);
    const u = await db.get('users', d.user_id);
    try {
      if (action === 'approve') {
        await db.rpc('approve_deposit', { p_id: d.id });
        const fresh = await db.get('users', u.id);
        notify(fresh, '✅ ডিপোজিট অনুমোদিত', `${d.amount} টাকা ওয়ালেটে যোগ হয়েছে। বর্তমান ব্যালেন্স: ${fresh.balance} টাকা`);
      } else if (action === 'reject') {
        if (d.status !== 'pending') return bad(res, 'ইতিমধ্যে প্রসেস করা হয়েছে');
        const b = await body(req);
        await db.update('deposits', d.id, { status: 'rejected', admin_note: String(b.note || '').slice(0, 200) });
        notify(u, '❌ ডিপোজিট বাতিল', `${d.amount} টাকার (TxID ${d.txid}) অনুরোধ যাচাই করা যায়নি। ${b.note || ''}`);
      } else return bad(res, 'not_found', 404);
      return send(res, 200, await db.get('deposits', d.id));
    } catch (e) { if (e.code === 'already_processed') return bad(res, 'ইতিমধ্যে প্রসেস করা হয়েছে'); throw e; }
  }

  if (name === 'orders' && id && action === 'status') {
    const b = await body(req); const o = await db.get('orders', id); if (!o) return bad(res, 'not_found', 404);
    const u = await db.get('users', o.user_id);
    const allowed = ['pending', 'processing', 'shipped', 'completed', 'cancelled'];
    if (!allowed.includes(b.status)) return bad(res, 'invalid_status');
    try {
      let r;
      if (b.status === 'cancelled') { const x = await db.rpc('cancel_order', { p_id: o.id }); r = Array.isArray(x) ? x[0] : x; notify(await db.get('users', u.id), '↩️ অর্ডার বাতিল ও রিফান্ড', `অর্ডার ${o.number} বাতিল হয়েছে, ${o.total} টাকা ওয়ালেটে ফেরত দেওয়া হয়েছে।`); }
      else {
        if (o.status === 'cancelled') return bad(res, 'বাতিল অর্ডার আর বদলানো যাবে না');
        r = await db.update('orders', o.id, { status: b.status, tracking: b.tracking ?? o.tracking });
        if (b.status === 'completed' && o.status !== 'completed') notify(u, '✅ অর্ডার সফল হয়েছে', `অর্ডার ${o.number} সম্পন্ন/ডেলিভারি হয়েছে।`);
        else if (b.status === 'shipped') notify(u, '🚚 অর্ডার পাঠানো হয়েছে', `অর্ডার ${o.number} শিপ হয়েছে।${b.tracking ? ' ট্র্যাকিং: ' + b.tracking : ''}`);
      }
      return send(res, 200, r);
    } catch (e) { if (e.code === 'cannot_cancel') return bad(res, 'এই অর্ডার বাতিল করা যাবে না'); throw e; }
  }

  if (name === 'broadcast' && req.method === 'POST') {
    const b = await body(req); if (!b.text) return bad(res, 'বার্তা লিখুন');
    const users = await db.list('users'); let n = 0;
    for (const u of users) { await notify(u, String(b.title || '📢 EntireBazar'), String(b.text)); n++; await new Promise((r) => setTimeout(r, 40)); }
    return send(res, 200, { sent: n });
  }

  if (READONLY.includes(name)) return send(res, 200, await db.list(name, { order: 'id.desc', limit: 500 }));

  if (CRUD.includes(name)) {
    if (req.method === 'GET') return send(res, 200, await db.list(name, { order: ['products', 'reviews', 'coupons'].includes(name) ? 'id.desc' : 'sort.asc' }));
    if (req.method === 'POST') { const b = clean(name, await body(req)); try { return send(res, 200, await db.insert(name, b)); } catch (e) { if (e.code === 'duplicate') return bad(res, 'এই কোড আগেই আছে'); throw e; } }
    if (req.method === 'PUT' && id) return send(res, 200, await db.update(name, id, clean(name, await body(req))));
    if (req.method === 'DELETE' && id) { await db.remove(name, id); return send(res, 200, { ok: true }); }
  }
  return bad(res, 'not_found', 404);
}

/* ---------- টেলিগ্রাম বট ওয়েবহুক ---------- */
async function botWebhook(req, res) {
  const b = await body(req); const m = b.message;
  if (m && m.text && m.text.startsWith('/start') && WEBAPP_URL)
    await tg('sendMessage', { chat_id: m.chat.id, text: 'EntireBazar-এ স্বাগতম! 🛍\nনিচের বোতামে চাপ দিয়ে শপ খুলুন।', reply_markup: { inline_keyboard: [[{ text: '🛍 EntireBazar খুলুন', web_app: { url: WEBAPP_URL } }]] } });
  send(res, 200, { ok: true });
}

/* ---------- স্ট্যাটিক ---------- */
const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.mp4': 'video/mp4', '.json': 'application/json' };
function serveStatic(res, root, rel) {
  const file = path.normalize(path.join(root, rel));
  if (!file.startsWith(root)) return bad(res, 'forbidden', 403);
  fs.readFile(file, (err, data) => {
    if (err) return send(res, 404, 'Not found', 'text/plain');
    res.writeHead(200, { 'Content-Type': (MIME[path.extname(file)] || 'application/octet-stream') + (path.extname(file) === '.html' || path.extname(file) === '.js' || path.extname(file) === '.css' ? '; charset=utf-8' : ''), 'Cache-Control': root.endsWith('uploads') ? 'public, max-age=31536000' : 'no-cache', 'X-Content-Type-Options': 'nosniff' });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname === '/health') return send(res, 200, { ok: true, db: db.isSupabase ? 'supabase' : 'memory' });
    if (url.pathname.startsWith('/api/admin')) return await adminApi(req, res, url);
    if (url.pathname === `/api/telegram/${WEBHOOK_SECRET}` && WEBHOOK_SECRET && req.method === 'POST') return await botWebhook(req, res);
    if (url.pathname.startsWith('/api/')) return await customerApi(req, res, url);
    if (url.pathname.startsWith('/uploads/')) return serveStatic(res, path.join(__dirname, 'uploads'), url.pathname.slice(9));
    if (url.pathname === '/admin' || url.pathname === '/admin/') return serveStatic(res, path.join(__dirname, 'public'), 'admin/index.html');
    return serveStatic(res, path.join(__dirname, 'public'), url.pathname === '/' ? 'index.html' : url.pathname.slice(1));
  } catch (e) {
    if (e.message === 'too_large') return bad(res, 'ফাইল অনেক বড়', 413);
    if (e.message === 'bad_json') return bad(res, 'bad_request');
    if (e.message === 'invalid_file_type') return bad(res, 'শুধু png/jpg/gif/webp (অ্যাডমিন: mp4) অনুমোদিত');
    if (e.message === 'invalid_file_size') return bad(res, 'ফাইল ৬MB-এর কম হতে হবে');
    console.error(e);
    return bad(res, 'সার্ভারে সমস্যা হয়েছে', 500);
  }
});
if (require.main === module) server.listen(PORT, () => console.log(`EntireBazar চলছে :${PORT} [db=${db.isSupabase ? 'supabase' : 'memory'}]`));
module.exports = { server, sign };
